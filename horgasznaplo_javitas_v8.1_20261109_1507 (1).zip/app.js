/* =====================================================================
   Horgásznapló – fő alkalmazáslogika
   Adatbázis: Supabase · Időjárás: Open-Meteo (CC BY 4.0)
   ===================================================================== */
(() => {
  "use strict";

  // Verziószám: új modul / funkció → főszám, kisebb javítás → alszám
  const APP_VERSION = "8.1";
  const CFG = window.APP_CONFIG || {};
  const TZ = CFG.TIMEZONE || "Europe/Budapest";
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

  // iPhone / iPad felismerése (az iPadOS asztali Safarinak adja ki magát)
  const IS_IOS = /iPad|iPhone|iPod/.test(navigator.userAgent) ||
    (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
  const IS_STANDALONE = window.matchMedia("(display-mode: standalone)").matches || window.navigator.standalone === true;

  const DEFAULT_SPECIES = [
    "Ponty", "Amur", "Busa", "Kárász", "Ezüstkárász", "Compó", "Dévérkeszeg",
    "Karikakeszeg", "Bodorka", "Vörösszárnyú keszeg", "Jászkeszeg", "Márna",
    "Paduc", "Balin", "Csuka", "Süllő", "Kősüllő", "Sügér", "Harcsa", "Angolna",
    "Sebes pisztráng", "Szivárványos pisztráng", "Naphal", "Törpeharcsa", "Kecsege"
  ];

  // WMO időjárás-kódok magyarul
  const WMO = {
    0: "derült", 1: "többnyire derült", 2: "részben felhős", 3: "borult",
    45: "köd", 48: "zúzmarás köd",
    51: "gyenge szitálás", 53: "szitálás", 55: "erős szitálás",
    56: "ónos szitálás", 57: "erős ónos szitálás",
    61: "gyenge eső", 63: "eső", 65: "erős eső",
    66: "ónos eső", 67: "erős ónos eső",
    71: "gyenge havazás", 73: "havazás", 75: "erős havazás", 77: "hószemcse",
    80: "gyenge zápor", 81: "zápor", 82: "heves zápor",
    85: "hózápor", 86: "erős hózápor",
    95: "zivatar", 96: "zivatar jégesővel", 99: "erős zivatar jégesővel"
  };

  // ------------------------------------------------------------------
  // Segédfüggvények
  // ------------------------------------------------------------------
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  }[c]));

  const numFmt = (n, d = 2) =>
    n == null || n === "" || isNaN(n) ? "" :
      Number(n).toLocaleString("hu-HU", { maximumFractionDigits: d });

  const dtFmt = (iso) => new Date(iso).toLocaleString("hu-HU", {
    timeZone: TZ, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit"
  });

  // A megadott időpont dátum/óra részei a beállított időzónában
  function tzParts(date) {
    const parts = new Intl.DateTimeFormat("en-CA", {
      timeZone: TZ, year: "numeric", month: "2-digit", day: "2-digit",
      hour: "2-digit", minute: "2-digit", hourCycle: "h23"
    }).formatToParts(date);
    const o = {};
    parts.forEach((p) => { o[p.type] = p.value; });
    return { y: o.year, m: o.month, d: o.day, h: o.hour, min: o.minute };
  }
  const yearOf = (iso) => tzParts(new Date(iso)).y;
  const monthOf = (iso) => { const p = tzParts(new Date(iso)); return `${p.y}.${p.m}.`; };

  // datetime-local mező értéke (a telefon helyi ideje szerint)
  function localInputValue(d = new Date()) {
    const pad = (n) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  }

  // ---- A fogás időpontja: két kézzel írható mező (dátum + idő) + rejtett ISO-mező ----
  const pad2 = (n) => String(n).padStart(2, "0");
  function setCatchTime(d) {
    $("#catchDate").value = `${d.getFullYear()}.${pad2(d.getMonth() + 1)}.${pad2(d.getDate())}`;
    $("#catchTime").value = `${pad2(d.getHours())}:${pad2(d.getMinutes())}`;
    syncCatchTime(true);
  }
  // A beírt szövegből Date (a telefon helyi ideje szerint), vagy null + hibaüzenet
  function parseCatchTime() {
    const ds = $("#catchDate").value.trim(), ts = $("#catchTime").value.trim();
    const dm = ds.match(/^(\d{4})[.\-\/ ]?(\d{1,2})[.\-\/ ]?(\d{1,2})\.?$/);
    const tm = ts.match(/^(\d{1,2})[:.]?(\d{2})$/);
    if (!dm) return { error: "A dátumot így add meg: ÉÉÉÉ.HH.NN (pl. 2026.10.12)." , field: "date" };
    if (!tm) return { error: "Az időt így add meg: ÓÓ:PP (pl. 06:40).", field: "time" };
    const y = +dm[1], mo = +dm[2], da = +dm[3], h = +tm[1], mi = +tm[2];
    const d = new Date(y, mo - 1, da, h, mi);
    if (d.getFullYear() !== y || d.getMonth() !== mo - 1 || d.getDate() !== da || h > 23 || mi > 59)
      return { error: "Nem létező dátum vagy idő.", field: h > 23 || mi > 59 ? "time" : "date" };
    return { date: d };
  }
  function syncCatchTime(quiet) {
    const r = parseCatchTime();
    const hidden = $("#catchForm").caught_at;
    $("#catchDate").classList.toggle("bad", !quiet && !!r.error && r.field === "date");
    $("#catchTime").classList.toggle("bad", !quiet && !!r.error && r.field === "time");
    const msg = $("#dtMsg");
    if (r.error) {
      hidden.value = "";
      msg.className = "msg err"; msg.textContent = quiet ? "" : r.error;
      return;
    }
    hidden.value = localInputValue(r.date);
    msg.className = "msg"; msg.textContent = "";
    checkLateTime();
  }
  // Gépelés közbeni formázás: pontok és kettőspont automatikusan
  function formatDateInput(e) {
    const el = e.target;
    let v = el.value.replace(/[^\d]/g, "").slice(0, 8);
    if (v.length > 6) v = `${v.slice(0, 4)}.${v.slice(4, 6)}.${v.slice(6)}`;
    else if (v.length > 4) v = `${v.slice(0, 4)}.${v.slice(4)}`;
    el.value = v;
    if (v.length === 10) { syncCatchTime(false); $("#catchTime").focus(); }
  }
  function formatTimeInput(e) {
    const el = e.target;
    let v = el.value.replace(/[^\d]/g, "").slice(0, 4);
    if (v.length > 2) v = `${v.slice(0, 2)}:${v.slice(2)}`;
    el.value = v;
    if (v.length === 5) syncCatchTime(false);
  }
  function shiftCatchTime(code) {
    if (code === "now") { setCatchTime(new Date()); return; }
    const r = parseCatchTime();
    const base = r.date || new Date();
    setCatchTime(new Date(base.getTime() + Number(code) * 60000));
  }

  function uuid() {
    if (crypto.randomUUID) return crypto.randomUUID();
    return "10000000-1000-4000-8000-100000000000".replace(/[018]/g, (c) =>
      (c ^ (crypto.getRandomValues(new Uint8Array(1))[0] & (15 >> (c / 4)))).toString(16));
  }

  let toastTimer;
  // A fontos üzenet (pl. egyéni rekord) a kiírás idejéig nem írható felül; a többi utána jelenik meg
  let toastHold = 0, toastQueue = [];
  function toast(msg, ms = 3000, important = false) {
    if (!important && Date.now() < toastHold) { toastQueue.push([msg, ms]); return; }
    const t = $("#toast");
    t.textContent = msg;
    t.classList.remove("hidden");
    clearTimeout(toastTimer);
    if (important) toastHold = Date.now() + ms;
    toastTimer = setTimeout(() => {
      t.classList.add("hidden");
      const next = toastQueue.shift();
      if (next) { toastQueue = []; toast(next[0], next[1]); }
    }, ms);
  }

  function errText(e) {
    const m = (e && (e.message || e.error_description || e.msg)) || String(e);
    if (/Invalid login credentials/i.test(m)) return "Hibás e-mail-cím vagy jelszó.";
    if (/Email not confirmed/i.test(m)) return "Az e-mail-cím még nincs megerősítve. Nézd meg a postafiókodat.";
    if (/already registered|already exists/i.test(m)) return "Ezzel az e-mail-címmel már van regisztráció.";
    if (/Password should be/i.test(m)) return "A jelszó túl rövid vagy túl egyszerű.";
    if (/Failed to fetch|NetworkError|network/i.test(m)) return "Nincs internetkapcsolat.";
    if (/Signups not allowed/i.test(m)) return "A regisztráció jelenleg le van zárva. Kérd az adminisztrátort.";
    if (/email rate limit|over_email_send_rate_limit/i.test(m)) return "Túl sok e-mail lett kiküldve. Az ingyenes levelező óránként csak néhány levelet küld; próbáld újra később.";
    if (/same.*password|New password should be different/i.test(m)) return "Az új jelszó nem lehet azonos a régivel.";
    if (/rate limit/i.test(m)) return "Túl sok próbálkozás. Várj egy kicsit, és próbáld újra.";
    return m;
  }

  // ------------------------------------------------------------------
  // Helyi tároló (IndexedDB): offline várólista + gyorsítótár
  // ------------------------------------------------------------------
  const idb = (() => {
    let dbp;
    function open() {
      if (dbp) return dbp;
      dbp = new Promise((resolve, reject) => {
        const req = indexedDB.open("horgasznaplo", 1);
        req.onupgradeneeded = () => {
          const db = req.result;
          if (!db.objectStoreNames.contains("outbox")) db.createObjectStore("outbox", { keyPath: "client_id" });
          if (!db.objectStoreNames.contains("kv")) db.createObjectStore("kv");
        };
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
      });
      return dbp;
    }
    async function tx(store, mode, fn) {
      const db = await open();
      return new Promise((resolve, reject) => {
        const t = db.transaction(store, mode);
        const s = t.objectStore(store);
        const r = fn(s);
        t.oncomplete = () => resolve(r && "result" in r ? r.result : undefined);
        t.onerror = () => reject(t.error);
        t.onabort = () => reject(t.error);
      });
    }
    return {
      put: (store, val, key) => tx(store, "readwrite", (s) => (key !== undefined ? s.put(val, key) : s.put(val))),
      get: (store, key) => tx(store, "readonly", (s) => s.get(key)),
      del: (store, key) => tx(store, "readwrite", (s) => s.delete(key)),
      all: (store) => tx(store, "readonly", (s) => s.getAll())
    };
  })();

  // ------------------------------------------------------------------
  // Állapot
  // ------------------------------------------------------------------
  const state = {
    sb: null,
    uid: null,
    me: null,            // saját profil
    profiles: {},        // id -> profil
    catches: [],         // szerveren lévő fogások
    outbox: [],          // szinkronizálásra váró saját fogások
    syncing: false,
    photo: null,         // { blob, url } az új fogás űrlapon
    gps: null,           // { lat, lon, acc, source: "gps" | "map" | "list" | "saved" }
    signedUrls: {},      // photo_path -> { url, exp }
    editing: null,       // szerkesztett fogás: { client_id, pending, original }
    recovery: false      // jelszó-visszaállítási link érkezett
  };

  let trips = null;     // Horgásztúra napló modul (trips.js)
  let records = null;   // Rekordlisták (records.js)
  let family = null;    // Nézelődők (family.js)
  let news = null;      // Újdonságok jelölése (news.js)
  let quotes = null;    // Napi idézet (quotes.js)
  let tally = null;     // Tabella (tally.js)
  let admin = null;     // Karbantartás: mentés, tárhely (admin.js)
  let cel = null;       // Ünnepi köszöntés, „Ma volt…” (celebrate.js)
  let inst = null;      // Telepítés alkalmazásként (install.js)
  // Nézelődő: mindent lát, de semmit nem módosíthat
  const isViewer = () => !!(state.me && state.me.role === "viewer");
  const viewerOk = (p) => !!(p && p.approved && (!p.viewer_until || new Date(p.viewer_until).getTime() > Date.now()));

  // ------------------------------------------------------------------
  // Nézetek
  // ------------------------------------------------------------------
  function show(viewId) {
    $$(".view").forEach((v) => v.classList.toggle("hidden", v.id !== viewId));
    const main = viewId === "viewMain";
    $("#btnHome").classList.toggle("hidden", !main || state.tab === "tabHome");
    $("#btnMenu").classList.toggle("hidden", !(main || viewId === "viewMembers" || viewId === "viewQuotes" || viewId === "viewAdmin" || viewId === "viewPending"));
    $("#menuPanel").classList.add("hidden");
  }

  // Nézetváltás. A kezdőlap a gyökér: onnan nyílik minden fül, a telefon „Vissza” gombja oda tér vissza.
  function showTab(tabId, opts) {
    if (isViewer() && (tabId === "tabNew" || tabId === "tabFamily")) { toast("Nézelődőként ez nem érhető el."); tabId = "tabHome"; }
    if (state.tab === "tabFamily" && tabId !== "tabFamily" && family) family.stopQr();
    const prev = state.tab;
    state.tab = tabId;
    if (news && prev !== tabId) {
      if (prev === "tabLog") news.leave("log");
      if (prev === "tabGallery") news.leave("gallery");
      if (prev === "tabTrips") news.leave("t:");
    }
    $$(".tab").forEach((t) => t.classList.toggle("hidden", t.id !== tabId));
    $("#btnHome").classList.toggle("hidden", tabId === "tabHome" || $("#viewMain").classList.contains("hidden"));
    document.documentElement.style.setProperty("--top-h", $(".topbar").offsetHeight + "px");
    if (!(opts && opts.pop)) {
      try {
        if (tabId === "tabHome") history.replaceState({ tab: "tabHome" }, "");
        else if (!prev || prev === "tabHome") history.pushState({ tab: tabId }, "");
        else history.replaceState({ tab: tabId }, "");
      } catch (_) { /* beágyazott nézetben nem elérhető */ }
    }
    if (tabId === "tabHome") renderHome();
    if (tabId === "tabFamily" && family) family.render();
    if (tabId === "tabLog") { renderLog(); updatePushHint(); }
    if (tabId === "tabGallery") renderGallery();
    if (tabId === "tabStats") renderStats();
    if (tabId === "tabTrips" && trips) trips.render();
    if (tabId === "tabNew" && !state.gps && !state.editing && isRecentTime()) requestGps(true);
    window.scrollTo(0, 0);
  }

  function updateNet() {
    const b = $("#netBadge");
    const on = navigator.onLine;
    b.textContent = on ? "Online" : "Offline";
    b.className = "badge " + (on ? "online" : "offline");
    const n = state.outbox.length;
    const s = $("#btnSync");
    s.classList.toggle("hidden", n === 0);
    s.textContent = state.syncing ? "⟳ Küldés…" : `⟳ ${n} vár`;
  }

  // ------------------------------------------------------------------
  // Indulás
  // ------------------------------------------------------------------
  async function start() {
    $("#clubName").textContent = CFG.CLUB_NAME || "Horgásznapló";
    $("#appVer").textContent = "v" + APP_VERSION;
    // A fejléc magassága (a ragadós elemek és a menü helyéhez)
    const topH = () => document.documentElement.style.setProperty("--top-h", $(".topbar").offsetHeight + "px");
    topH(); window.addEventListener("resize", topH); setTimeout(topH, 300);
    document.title = (CFG.CLUB_NAME ? CFG.CLUB_NAME + " – " : "") + "Horgásznapló";

    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("sw.js").catch(() => {});
    }

    bindUi();
    if (typeof window.TFTNews === "function") news = window.TFTNews({ state, idb });
    if (typeof window.TFTQuotes === "function") quotes = window.TFTQuotes({ state, $, esc, toast, errText, idb, tzParts, show, renderHome: () => renderHome() });
    if (typeof window.TFTTally === "function") tally = window.TFTTally({ esc, numFmt, nameOf });
    if (typeof window.TFTCelebrateUI === "function" && window.TFTCelebrate) cel = window.TFTCelebrateUI({
      state, $, esc, toast, errText, numFmt, dtFmt, nameOf, callFn: (action, extra) => callFn(Object.assign({ action, url: APP_URL }, extra)),
      entries: () => allEntries(), trips: () => (trips ? trips.all() : []),
      openTrip: (id) => { if (trips) { showTab("tabTrips"); trips.open(id); } },
      openCatch: (cid) => { location.hash = "#fogas-" + cid; openCatchFromHash(); },
      afterSave: () => { if (!$("#viewMembers").classList.contains("hidden")) showMembers(); else if (state.tab === "tabHome") renderHome(); }
    });
    if (typeof window.TFTInstall === "function") { inst = window.TFTInstall({ $, toast, onChange: () => { if (state.tab === "tabHome" && !$("#viewMain").classList.contains("hidden")) renderHome(); } }); inst.refresh(); }
    if (typeof window.TFTAdmin === "function") admin = window.TFTAdmin({ state, $, esc, toast, errText, idb, tzParts, dtFmt, show, APP_VERSION, renderHome: () => renderHome() });
    if (typeof window.TFTTrips === "function") {
      trips = window.TFTTrips({ news, tally,
        state, $, esc, numFmt, dtFmt, tzParts, toast, errText, idb, uuid, TZ, CFG, APP_URL,
        nameOf, anglerOf, everyEntry, cardHtml, loadThumbs, photoCount, catchPhotoPaths, captionOf,
        signedUrlsFor, openViewer, prepareImage, uploadPhoto, extOf, openMap, windDir, callFn, showTab, startCatchForTrip, coverPath, exifDate, placeLabel, countdownHtml
      });
    }
    if (typeof window.TFTFamily === "function") {
      family = window.TFTFamily({ state, $, esc, dtFmt, toast, errText, nameOf, show, enterApp, showMembers, APP_URL, CFG });
    }
    if (typeof window.TFTRecords === "function") {
      records = window.TFTRecords({ $, esc, numFmt, dtFmt, tzParts, nameOf, allEntries, cardHtml, loadThumbs, trips,
        dayRange, inDayRange, quickRange, dayInput, formatDayInput, parseDay });
    }
    updateNet();

    // iPhone-on, ha nincs telepítve: figyelmeztetés a kezdőképernyőre tételről
    let iosHidden = false;
    try { iosHidden = localStorage.getItem("iosInstallHidden") === "1"; } catch (_) { /* nincs tároló */ }
    if (IS_IOS && !IS_STANDALONE && !iosHidden) $("#iosInstall").classList.remove("hidden");
    $("#btnIosHide").addEventListener("click", () => {
      $("#iosInstall").classList.add("hidden");
      try { localStorage.setItem("iosInstallHidden", "1"); } catch (_) { /* nincs tároló */ }
    });

    const configured = CFG.SUPABASE_URL && /^https:\/\//.test(CFG.SUPABASE_URL) &&
      CFG.SUPABASE_KEY && !/^IDE_JON/.test(CFG.SUPABASE_KEY);
    if (!configured || !window.supabase) { show("viewConfig"); return; }

    // Jelszó-visszaállító linkről érkezett? (az URL-ben "type=recovery" szerepel)
    state.recovery = /type=recovery/.test(location.hash);

    state.sb = window.supabase.createClient(CFG.SUPABASE_URL, CFG.SUPABASE_KEY, {
      auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true, flowType: "implicit" }
    });

    state.inviteToken = family ? family.readToken() : null;

    state.sb.auth.onAuthStateChange((event, sess) => {
      if (event === "PASSWORD_RECOVERY") {
        state.recovery = true;
        if (sess) state.uid = sess.user.id;
        show("viewNewPassword");
        return;
      }
      if (state.recovery) return;
      if (event === "SIGNED_OUT") {
        state.uid = null; state.me = null;
        show("viewAuth");
      } else if (sess && !state.uid && !state.redeeming) {
        state.uid = sess.user.id;
        setTimeout(() => enterApp(), 0);
      }
    });

    state.outbox = (await idb.all("outbox").catch(() => [])) || [];
    updateNet();

    let session = null;
    try {
      const { data } = await state.sb.auth.getSession();
      session = data.session;
    } catch (_) { /* offline */ }

    if (state.recovery) {
      if (session) state.uid = session.user.id;
      show("viewNewPassword");
    } else if (state.inviteToken && family && navigator.onLine && await family.handleInvite(session).catch(() => false)) {
      // Meghívó: a nézelődő a meghívó képernyőn folytatja
      if (session) state.uid = session.user.id;
    } else if (session) {
      state.uid = session.user.id;
      await enterApp();
    } else {
      // Offline indulás: ha korábban már be volt jelentkezve, a tárolt adatokkal folytatjuk
      const cachedMe = await idb.get("kv", "me").catch(() => null);
      if (!navigator.onLine && cachedMe && cachedMe.approved) {
        state.uid = cachedMe.id;
        state.me = cachedMe;
        await loadCache();
        enterMain();
        toast("Offline mód – a fogások a kapcsolat helyreállása után kerülnek fel.");
      } else {
        show("viewAuth");
      }
    }
  }

  async function loadCache() {
    state.catches = (await idb.get("kv", "catches").catch(() => null)) || [];
    state.profiles = (await idb.get("kv", "profiles").catch(() => null)) || {};
    if (trips) await trips.loadCache();
    if (news) await news.loadCache();
    if (quotes) await quotes.loadCache();
    if (admin) await admin.loadCache();
  }

  let entering = null;
  function enterApp() {
    if (!entering) entering = doEnterApp().finally(() => { entering = null; });
    return entering;
  }

  async function doEnterApp() {
    if (state.recovery) return;
    await loadCache();
    try {
      const { data, error } = await state.sb.from("profiles").select("*").eq("id", state.uid).maybeSingle();
      if (error) throw error;
      if (data) { state.me = data; await idb.put("kv", data, "me"); }
    } catch (e) {
      state.me = (await idb.get("kv", "me").catch(() => null)) || state.me;
    }

    if (!state.me) {
      // A profil a regisztrációkor jön létre; ha még nincs, várakozó állapot
      show("viewPending");
      return;
    }
    if (isViewer()) {
      if (!viewerOk(state.me)) { if (family) family.showExpired(); else show("viewPending"); return; }
    } else if (!state.me.approved) { show("viewPending"); return; }

    enterMain();
    refreshData();
    syncOutbox();
  }

  function enterMain() {
    $("#menuUser").textContent = `${state.me.display_name || ""}${isViewer() ? " (nézelődő)" : state.me.is_admin ? " (admin)" : ""}`;
    $("#menuMembers").classList.toggle("hidden", !state.me.is_admin || isViewer());
    $("#menuQuotes").classList.toggle("hidden", !state.me.is_admin || isViewer());
    $("#menuAdmin").classList.toggle("hidden", !state.me.is_admin || isViewer());
    $("#menuCel").classList.toggle("hidden", isViewer());
    show("viewMain");
    resetForm();
    fillDatalists();
    try { history.replaceState({ tab: "tabHome" }, ""); } catch (_) { /* nem elérhető */ }
    state.tab = null;
    showTab("tabHome");
    updatePushMenu();
    openCatchFromHash();
  }

  async function refreshData() {
    if (!navigator.onLine || !state.sb) return;
    // A saját profil frissítése (nézelődő: lejárat, meghosszabbítás)
    if (state.uid) {
      try {
        const me = await state.sb.from("profiles").select("*").eq("id", state.uid).maybeSingle();
        if (me.data) { state.me = me.data; await idb.put("kv", me.data, "me"); }
      } catch (_) { /* offline */ }
      if (isViewer() && !viewerOk(state.me)) { if (family) family.showExpired(); return; }
    }
    if (news) await news.load();
    if (quotes) await quotes.loadDaily();
    if (admin) await admin.fetchUsage();
    try {
      const pr = await state.sb.from("profiles").select("*");
      if (pr.error) throw pr.error;
      // A szerver lekérdezésenként legfeljebb 1000 sort ad, ezért lapozva töltjük le
      const PAGE = 1000;
      let rows = [];
      for (let from = 0; ; from += PAGE) {
        const cr = await state.sb.from("catches").select("*")
          .order("caught_at", { ascending: false }).order("id")
          .range(from, from + PAGE - 1);
        if (cr.error) throw cr.error;
        rows = rows.concat(cr.data);
        if (cr.data.length < PAGE) break;
      }
      state.profiles = {};
      pr.data.forEach((p) => { state.profiles[p.id] = p; });
      state.catches = rows;
      await idb.put("kv", state.profiles, "profiles");
      await idb.put("kv", state.catches, "catches");
      fillDatalists();
      if (!$("#tabLog").classList.contains("hidden")) renderLog();
      if (!$("#tabStats").classList.contains("hidden")) renderStats();
      if (!$("#tabGallery").classList.contains("hidden")) renderGallery();
      if (!$("#tabHome").classList.contains("hidden")) renderHome();
    } catch (e) {
      console.warn("Frissítés sikertelen:", e);
    }
    if (trips) await trips.refresh();
    if (state.tab === "tabHome") renderHome();
    // Ünnepi köszöntés: az adatok betöltése után, naponta egyszer
    if (cel && (!isViewer() || viewerOk(state.me))) cel.maybePopup();
  }

  // ------------------------------------------------------------------
  // Bejelentkezés / regisztráció
  // ------------------------------------------------------------------
  let authMode = "login";
  function setAuthMode(mode) {
    authMode = mode;
    $$(".seg-btn").forEach((b) => b.classList.toggle("active", b.dataset.auth === mode));
    $$(".reg-only").forEach((el) => el.classList.toggle("hidden", mode !== "register"));
    ["#regBM", "#regBD"].forEach((s) => { if ($(s)) $(s).required = mode === "register"; });
    $("#authSubmit").textContent = mode === "login" ? "Belépés" : "Regisztráció";
    $("#btnForgot").classList.toggle("hidden", mode !== "login");
    $("#authForm").password.autocomplete = mode === "login" ? "current-password" : "new-password";
    $("#authMsg").textContent = "";
  }

  async function onAuthSubmit(ev) {
    ev.preventDefault();
    const f = ev.target;
    const msg = $("#authMsg");
    msg.className = "msg";
    const email = f.email.value.trim();
    const password = f.password.value;
    const btn = $("#authSubmit");
    btn.disabled = true;
    msg.textContent = "Folyamatban…";
    try {
      if (authMode === "login") {
        const { data, error } = await state.sb.auth.signInWithPassword({ email, password });
        if (error) throw error;
        state.uid = data.user.id;
        msg.textContent = "";
        await enterApp();
      } else {
        const name = f.display_name.value.trim();
        if (!name) throw new Error("Add meg a nevet, ahogy a listákban megjelenjen.");
        const bm = Number($("#regBM").value), bd = Number($("#regBD").value);
        if (!bm || !bd) throw new Error("Add meg a születésnapodat (hónap és nap).");
        if (cel && !cel.validMd(bm, bd)) throw new Error("Érvénytelen dátum – ellenőrizd a születésnapot.");
        const { data, error } = await state.sb.auth.signUp({
          email, password,
          options: { data: { display_name: name, birth_month: bm, birth_day: bd }, emailRedirectTo: location.href.split("#")[0] }
        });
        if (error) throw error;
        if (data.session) {
          state.uid = data.user.id;
          msg.textContent = "";
          await enterApp();
        } else {
          setAuthMode("login");
          msg.className = "msg ok";
          msg.textContent = "Sikeres regisztráció. Erősítsd meg az e-mail-címedet a kapott levélben, majd lépj be.";
        }
      }
    } catch (e) {
      msg.className = "msg err";
      msg.textContent = errText(e);
    } finally {
      btn.disabled = false;
    }
  }

  // Elfelejtett jelszó: visszaállító link e-mailben
  async function forgotPassword() {
    const msg = $("#authMsg");
    const email = $("#authForm").email.value.trim();
    msg.className = "msg";
    if (!email || !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
      msg.className = "msg err";
      msg.textContent = "Írd be fent az e-mail-címedet, majd kattints újra az „Elfelejtettem a jelszavam” gombra.";
      $("#authForm").email.focus();
      return;
    }
    if (!navigator.onLine) { msg.className = "msg err"; msg.textContent = "Nincs internetkapcsolat."; return; }
    const btn = $("#btnForgot");
    btn.disabled = true;
    msg.textContent = "Küldés…";
    try {
      const redirectTo = APP_URL;
      const { error } = await state.sb.auth.resetPasswordForEmail(email, { redirectTo });
      if (error) throw error;
      msg.className = "msg ok";
      msg.textContent = "Ha ezzel a címmel van regisztráció, hamarosan érkezik egy levél a jelszó-visszaállító linkkel. Nézd meg a levélszemét mappát is.";
    } catch (e) {
      msg.className = "msg err";
      msg.textContent = errText(e);
    } finally {
      btn.disabled = false;
    }
  }

  async function onNewPassword(ev) {
    ev.preventDefault();
    const msg = $("#newPassMsg");
    const p1 = $("#newPass1").value, p2 = $("#newPass2").value;
    msg.className = "msg err";
    if (p1.length < 8) { msg.textContent = "A jelszó legalább 8 karakter legyen."; return; }
    if (p1 !== p2) { msg.textContent = "A két jelszó nem egyezik."; return; }
    const btn = $("#btnNewPass");
    btn.disabled = true;
    msg.className = "msg"; msg.textContent = "Mentés…";
    try {
      const { error } = await state.sb.auth.updateUser({ password: p1 });
      if (error) throw error;
      state.recovery = false;
      history.replaceState(null, "", location.pathname + location.search);
      $("#newPass1").value = ""; $("#newPass2").value = "";
      toast("Az új jelszó mentve.");
      const { data } = await state.sb.auth.getSession();
      if (data.session) { state.uid = data.session.user.id; await enterApp(); }
      else show("viewAuth");
    } catch (e) {
      msg.className = "msg err";
      msg.textContent = /session/i.test(String(e && e.message)) ?
        "A visszaállító link lejárt vagy már felhasználták. Kérj új linket a belépő oldalon." : errText(e);
    } finally {
      btn.disabled = false;
    }
  }

  async function logout() {
    if (isViewer() && !state.me.email_login) {
      let anon = false;
      try { const { data } = await state.sb.auth.getUser(); anon = !!(data && data.user && data.user.is_anonymous); } catch (_) { /* offline */ }
      if (anon && !confirm("Gyors belépéssel (e-mail nélkül) vagy bent. Kijelentkezés után ezen a telefonon csak új meghívóval léphetsz be újra. Kijelentkezel?")) return;
    }
    if (state.outbox.length && !confirm(`${state.outbox.length} fogás még nincs feltöltve. Kijelentkezés után is megmaradnak ezen a telefonon, és a következő belépéskor feltöltődnek. Kijelentkezel?`)) return;
    $("#menuPanel").classList.add("hidden");
    try { await state.sb.auth.signOut(); } catch (_) { /* offline */ }
    await idb.del("kv", "me").catch(() => {});
    state.uid = null; state.me = null;
    if (news) news.reset();
    if (quotes) quotes.reset();
    if (admin) admin.reset();
    show("viewAuth");
  }

  // ------------------------------------------------------------------
  // Új fogás űrlap
  // ------------------------------------------------------------------
  function fillDatalists() {
    const uniq = (arr) => Array.from(new Set(arr.filter(Boolean).map((s) => s.trim()))).sort((a, b) => a.localeCompare(b, "hu"));
    const all = state.catches.concat(state.outbox);
    const species = uniq(DEFAULT_SPECIES.concat(all.map((c) => c.species)));
    $("#speciesList").innerHTML = species.map((s) => `<option value="${esc(s)}">`).join("");
    $("#waterList").innerHTML = uniq(all.map((c) => c.water)).map((s) => `<option value="${esc(s)}">`).join("");
    $("#baitList").innerHTML = uniq(all.map((c) => c.bait)).map((s) => `<option value="${esc(s)}">`).join("");
    fillPlaces();
  }

  function resetForm(forEdit) {
    const f = $("#catchForm");
    const wasEditing = !!state.editing;
    const keepWater = wasEditing ? "" : f.water.value;
    f.reset();
    f.water.value = keepWater; // ugyanazon a vízen általában több hal is jön
    setCatchTime(new Date());
    clearPhoto();
    state.photoRemoved = false;
    state.editing = null;
    $("#formTitle").textContent = "Új fogás";
    $("#btnCancelEdit").classList.add("hidden");
    $("#btnSave").textContent = "Mentés";
    $("#editInfo").classList.add("hidden");
    f.classList.remove("editing");
    $("#saveMsg").textContent = "";
    $("#lateWarn").classList.add("hidden");
    state.tripCtx = null;
    $("#tripCtx").classList.add("hidden");
    $("#placeMsg").textContent = "";
    // Friss fogásnál a GPS-pozíció megmarad (ugyanaz a hely), egyébként törlődik
    if (forEdit || wasEditing || (state.gps && state.gps.source !== "gps")) setLocation(null);
    else renderLocation();
  }

  // ------------------------------------------------------------------
  // Fotók az űrlapon (legfeljebb MAX_PHOTOS, egy közülük a listakép)
  // state.photos: [{ id, blob?, path?, url, objUrl? }], state.coverId
  // ------------------------------------------------------------------
  const MAX_PHOTOS = 6;
  let photoSeq = 0;

  function clearPhoto() {
    (state.photos || []).forEach((p) => { if (p.objUrl) URL.revokeObjectURL(p.objUrl); });
    state.photos = [];
    state.coverId = null;
    $("#photoCamera").value = "";
    $("#photoGallery").value = "";
    setPhotoMsg("");
    renderPhotoGrid();
  }

  function addFormPhoto(p) {
    p.id = ++photoSeq;
    state.photos.push(p);
    if (state.coverId == null) state.coverId = p.id;
  }

  function renderPhotoGrid() {
    const g = $("#photoGrid");
    const list = state.photos || [];
    if (!list.length) {
      g.innerHTML = `<div class="ph-empty">Nincs fotó</div>`;
    } else {
      g.innerHTML = list.map((p) => {
        const cover = p.id === state.coverId;
        return `<div class="ph${cover ? " cover" : ""}" data-pid="${p.id}">
          ${p.url ? `<img src="${esc(p.url)}" alt="">` : ""}
          <button type="button" class="ph-btn star${cover ? " on" : ""}" data-star="${p.id}" aria-label="Legyen ez a listakép" title="Legyen ez a listakép">${cover ? "★" : "☆"}</button>
          <button type="button" class="ph-btn del" data-del="${p.id}" aria-label="Fotó törlése" title="Fotó törlése">✕</button>
          ${cover ? `<div class="ph-label">Listakép</div>` : ""}
        </div>`;
      }).join("");
    }
    const full = list.length >= MAX_PHOTOS;
    ["#lblCamera", "#lblGallery"].forEach((sel) => $(sel).classList.toggle("hidden", full));
  }

  function onPhotoGridClick(e) {
    const star = e.target.closest("[data-star]");
    const del = e.target.closest("[data-del]");
    if (star) { state.coverId = Number(star.dataset.star); renderPhotoGrid(); }
    if (del) {
      const id = Number(del.dataset.del);
      const p = state.photos.find((x) => x.id === id);
      if (p && p.objUrl) URL.revokeObjectURL(p.objUrl);
      state.photos = state.photos.filter((x) => x.id !== id);
      if (state.coverId === id) state.coverId = state.photos.length ? state.photos[0].id : null;
      renderPhotoGrid();
    }
  }

  // Fotó kicsinyítése (max. 1600 px, JPEG) – kíméli az adatforgalmat és a tárhelyet
  function compressImage(file, maxSide = 1600, quality = 0.8) {
    return new Promise((resolve, reject) => {
      const url = URL.createObjectURL(file);
      const img = new Image();
      img.onload = () => {
        const scale = Math.min(1, maxSide / Math.max(img.naturalWidth, img.naturalHeight));
        const w = Math.round(img.naturalWidth * scale);
        const h = Math.round(img.naturalHeight * scale);
        const canvas = document.createElement("canvas");
        canvas.width = w; canvas.height = h;
        canvas.getContext("2d").drawImage(img, 0, 0, w, h);
        URL.revokeObjectURL(url);
        canvas.toBlob((b) => (b ? resolve(b) : reject(new Error("A fotó feldolgozása nem sikerült."))), "image/jpeg", quality);
      };
      img.onerror = () => { URL.revokeObjectURL(url); reject(new Error("A fotó nem olvasható.")); };
      img.src = url;
    });
  }

  // Második út: createImageBitmap (néhány böngészőben megbízhatóbb, mint az <img>)
  async function compressViaBitmap(file, maxSide = 1600, quality = 0.8) {
    if (!window.createImageBitmap) throw new Error("nincs createImageBitmap");
    const bmp = await createImageBitmap(file, { imageOrientation: "from-image" });
    const scale = Math.min(1, maxSide / Math.max(bmp.width, bmp.height));
    const canvas = document.createElement("canvas");
    canvas.width = Math.round(bmp.width * scale);
    canvas.height = Math.round(bmp.height * scale);
    canvas.getContext("2d").drawImage(bmp, 0, 0, canvas.width, canvas.height);
    if (bmp.close) bmp.close();
    return new Promise((resolve, reject) =>
      canvas.toBlob((b) => (b ? resolve(b) : reject(new Error("toBlob"))), "image/jpeg", quality));
  }

  function setPhotoMsg(text, isErr) {
    const m = $("#photoMsg");
    m.textContent = text || "";
    m.className = "msg" + (text ? (isErr ? " err" : " ok") : "");
  }

  async function prepareImage(file) {
    let blob = null, note = "";
    try { blob = await compressImage(file); }
    catch (_) {
      try { blob = await compressViaBitmap(file); } catch (_) { blob = null; }
    }
    // Ha a telefon nem tudja kicsinyíteni (pl. HEIC), az eredeti fájlt mentjük, max. 10 MB-ig
    if (!blob) {
      const heic = /hei[cf]/i.test(file.type) || /\.hei[cf]$/i.test(file.name || "");
      if (heic && file.size > 0 && file.size <= 10 * 1024 * 1024) {
        blob = new Blob([file], { type: file.type || "image/heic" });
        note = "eredeti méretben";
      } else {
        throw new Error(`A fotó nem dolgozható fel (${file.type || "ismeretlen formátum"}, ${Math.round(file.size / 1024)} kB).`);
      }
    }
    return { blob, note };
  }

  async function onPhotoPicked(ev) {
    const input = ev.target;
    const files = Array.from(input.files || []);
    input.value = "";
    if (!files.length) return;
    const room = MAX_PHOTOS - state.photos.length;
    if (room <= 0) { setPhotoMsg(`Legfeljebb ${MAX_PHOTOS} fotó csatolható.`, true); return; }
    const take = files.slice(0, room);
    setPhotoMsg(take.length > 1 ? `${take.length} fotó feldolgozása…` : "Fotó feldolgozása…");
    let added = 0; const errors = [];
    for (const f of take) {
      try {
        const { blob } = await prepareImage(f);
        const objUrl = URL.createObjectURL(blob);
        addFormPhoto({ blob, url: objUrl, objUrl });
        added++;
      } catch (e) { errors.push(errText(e)); }
    }
    renderPhotoGrid();
    const skipped = files.length - take.length;
    const parts = [];
    if (added) parts.push(`${added} fotó csatolva (összesen ${state.photos.length}).`);
    if (skipped) parts.push(`${skipped} fotó kimaradt: legfeljebb ${MAX_PHOTOS} csatolható.`);
    if (errors.length) parts.push(errors[0] + " Próbálj másik fotót választani.");
    setPhotoMsg(parts.join(" "), !added);
  }

  const extOf = (type) => ({ "image/png": "png", "image/webp": "webp", "image/heic": "heic", "image/heif": "heif" })[type] || "jpg";
  async function uploadPhoto(blob, path) {
    const type = blob.type || "image/jpeg";
    const { error } = await state.sb.storage.from("photos").upload(path, blob, { contentType: type, upsert: true });
    if (error) throw error;
    return path;
  }
  // Ha a 3. verziós adatbázis-frissítés még nem futott le, a "photos" oszlop nélkül próbálja újra
  const missingCol = (err, col) => err && new RegExp(col).test((err.message || "") + (err.details || "") + (err.hint || ""));

  // Egy fogás fotói: feltöltött útvonalak (szerver) vagy helyi képek (várólista)
  function catchPhotoPaths(c) {
    if (Array.isArray(c.photos) && c.photos.length && typeof c.photos[0] === "string") return c.photos;
    return c.photo_path ? [c.photo_path] : [];
  }
  function pendingPhotoBlobs(c) {
    if (Array.isArray(c.photos) && c.photos.length && c.photos[0] && c.photos[0].blob) return c.photos.map((p) => p.blob);
    return c.photo ? [c.photo] : [];
  }
  function photoCount(c) { return c._pending ? pendingPhotoBlobs(c).length : catchPhotoPaths(c).length; }
  function coverPath(c) {
    const paths = catchPhotoPaths(c);
    return c.photo_path && paths.includes(c.photo_path) ? c.photo_path : paths[0] || c.photo_path || null;
  }
  function coverBlob(c) {
    const b = pendingPhotoBlobs(c);
    return b[Math.min(c.cover_index || 0, Math.max(0, b.length - 1))] || null;
  }

  // ------------------------------------------------------------------
  // A fogás helye: GPS / térkép / korábbi helyek
  // ------------------------------------------------------------------
  const RECENT_MINUTES = 60; // ennél régebbi időpontnál utólagos rögzítésnek számít

  function isRecentTime() {
    const v = $("#catchForm").caught_at.value;
    if (!v) return true;
    const t = new Date(v).getTime();
    return isNaN(t) || Math.abs(Date.now() - t) <= RECENT_MINUTES * 60000;
  }

  function setLocation(loc) {
    state.gps = loc;
    // Más forrású hely (GPS, térkép, törlés) esetén a „Korábbi helyek” választás már nem érvényes
    if (!loc || loc.source !== "list") { const sel = $("#prevPlaces"); if (sel) sel.value = ""; const m = $("#placeMsg"); if (m) m.textContent = ""; }
    renderLocation();
  }

  function renderLocation() {
    const st = $("#gpsStatus");
    const g = state.gps;
    $("#btnLocClear").classList.toggle("hidden", !g);
    if (!g) {
      st.textContent = isRecentTime()
        ? "Még nincs megadva."
        : "Még nincs megadva. Jelöld ki a térképen, vagy válassz a korábbi helyek közül.";
      return;
    }
    const src = { gps: "jelenlegi pozíció (GPS)", map: "térképen kijelölve", list: "korábbi helyről", saved: "mentett hely" }[g.source] || "";
    st.textContent = `${g.lat.toFixed(5)}, ${g.lon.toFixed(5)}${g.acc ? ` (±${Math.round(g.acc)} m)` : ""} – ${src}`;
  }

  // Ha az időpont régebbi: figyelmeztetés, és az automatikusan kapott GPS-pozíciót elvetjük
  function checkLateTime() {
    const late = !isRecentTime();
    const w = $("#lateWarn");
    w.classList.toggle("hidden", !late);
    if (late) {
      w.textContent = "Utólagos rögzítés: a jelenlegi tartózkodási helyed valószínűleg nem a fogás helye. Add meg a helyet a térképen vagy a korábbi helyek közül.";
      if (state.gps && state.gps.source === "gps" && state.gps.auto) {
        setLocation(null);
        toast("Az automatikus pozíciót töröltem, mert a fogás időpontja korábbi.");
      }
    }
    renderLocation();
  }

  function requestGps(auto) {
    const st = $("#gpsStatus");
    if (!("geolocation" in navigator)) { st.textContent = "Ez a készülék nem támogatja a helymeghatározást."; return; }
    if (auto && !isRecentTime()) return;
    st.textContent = "Pozíció keresése…";
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        if (auto && (!isRecentTime() || (state.gps && state.gps.source !== "gps"))) return; // közben mást választott
        setLocation({ lat: pos.coords.latitude, lon: pos.coords.longitude, acc: pos.coords.accuracy, source: "gps", auto: !!auto });
        if (!auto && !isRecentTime()) toast("Figyelem: a jelenlegi helyedet rögzítettem, de a fogás időpontja korábbi.");
      },
      (err) => {
        if (state.gps) { renderLocation(); return; }
        st.textContent = err.code === 1
          ? "A helymeghatározás nincs engedélyezve. Engedélyezd a böngésző beállításaiban, vagy jelöld ki a helyet a térképen."
          : "Nem sikerült pozíciót kapni. Próbáld újra a szabad ég alatt, vagy jelöld ki a helyet a térképen.";
      },
      { enableHighAccuracy: true, timeout: 20000, maximumAge: 60000 }
    );
  }

  // Korábbi fogáshelyek (a társaság összes fogásából, gyakoriság szerint)
  // Korábbi helyek: vízterület + állás szerint egyszer (GPS nélküli helyek is).
  // A pozíció a hely legutóbbi, helymeghatározással rögzített fogásáé.
  const placeKey = (v) => String(v || "").toLowerCase().replace(/\s+/g, " ").replace(/\s*([-–,.])\s*/g, "$1").trim();
  function groupPlaces(keyFn, nameFn) {
    const map = new Map();
    state.catches.concat(state.outbox)
      .slice().sort((a, b) => (a.caught_at < b.caught_at ? 1 : -1))
      .forEach((c) => {
        if (!(c.water || "").trim()) return;
        const key = keyFn(c);
        const e = map.get(key) || { names: {}, spots: {}, lat: null, lon: null, n: 0, mine: 0 };
        const w = nameFn ? nameFn(c) : c.water.trim(), sp = (c.spot || "").trim();
        e.names[w] = (e.names[w] || 0) + 1;
        if (sp) e.spots[sp] = (e.spots[sp] || 0) + 1;
        if (e.lat == null && c.lat != null && c.lon != null) { e.lat = Number(c.lat); e.lon = Number(c.lon); }
        e.n++;
        if (c.user_id === state.uid) e.mine++;
        map.set(key, e);
      });
    const top = (o) => Object.keys(o).sort((a, b) => o[b] - o[a])[0] || "";
    return Array.from(map.values()).map((e) => ({ water: top(e.names), spot: top(e.spots), lat: e.lat, lon: e.lon, n: e.n, mine: e.mine }))
      .sort((a, b) => b.mine - a.mine || b.n - a.n || a.water.localeCompare(b.water, "hu"));
  }
  const placeLabel = (p, withSpot) => `${esc(p.water)}${withSpot && p.spot ? " – " + esc(p.spot) : ""} (${p.n}×)${p.lat == null ? " · GPS nélkül" : ""}`;
  function fillPlaces() {
    state.places = groupPlaces((c) => placeKey(c.water) + "|" + placeKey(c.spot));
    // Túrákhoz: csak a vízterület alapneve („Zagyva, jászberényi szakasz” → „Zagyva”), mert a túra így minden szakaszt lefed
    const baseWater = (w) => String(w || "").split(/[,(]| - | – /)[0].trim();
    state.waterPlaces = groupPlaces((c) => placeKey(baseWater(c.water)), (c) => baseWater(c.water));
    const sel = $("#prevPlaces");
    sel.innerHTML = `<option value="">${state.places.length ? "— válassz a korábbi fogáshelyek közül —" : "— még nincs korábbi fogáshely —"}</option>` +
      state.places.map((p, i) => `<option value="${i}">${placeLabel(p, true)}</option>`).join("");
  }

  function onPlacePicked() {
    const sel = $("#prevPlaces");
    const p = state.places && state.places[Number(sel.value)];
    const msg = $("#placeMsg");
    if (!p) { msg.textContent = ""; return; }
    const f = $("#catchForm");
    if (p.water) f.water.value = p.water;
    if (p.spot) f.spot.value = p.spot;
    const what = `${p.water}${p.spot ? " – " + p.spot : ""}`;
    if (p.lat != null) {
      setLocation({ lat: p.lat, lon: p.lon, acc: null, source: "list" });
      msg.className = "msg ok"; msg.textContent = `✓ ${what}: vízterület, állás és pozíció beállítva.`;
    } else {
      msg.className = "msg warn"; msg.textContent = `✓ ${what}: vízterület és állás beírva. GPS-pozíció ehhez a helyhez nincs – az időjáráshoz jelöld ki a térképen.`;
    }
  }

  // Térképes kijelölés (Leaflet + OpenStreetMap; internet kell hozzá)
  let lmap = null, lmarker = null, pick = null, mapCtx = null;
  // opts (nem kötelező): { center: {lat, lon}, onPick(lat, lon) } – pl. a túra helyének kijelöléséhez
  function openMap(opts) {
    mapCtx = opts && opts.onPick ? opts : null;
    const own = mapCtx ? (mapCtx.center || null) : state.gps;
    if (!window.L) { toast("A térkép nem töltődött be. Ellenőrizd az internetkapcsolatot."); return; }
    if (!navigator.onLine) { toast("A térképhez internetkapcsolat kell. Offline a korábbi helyek közül választhatsz."); return; }
    $("#mapModal").classList.remove("hidden");
    const last = state.catches.find((c) => c.lat != null);
    const center = own ? [own.lat, own.lon] : last ? [last.lat, last.lon] : [47.16, 19.5];
    const zoom = own ? 15 : last ? 12 : 7;
    if (!lmap) {
      lmap = L.map("mapCanvas", { zoomControl: true });
      L.tileLayer(CFG.MAP_TILES || "https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
        maxZoom: 19,
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> közreműködők'
      }).addTo(lmap);
      lmap.on("click", (e) => setPick(e.latlng.lat, e.latlng.lng));
    }
    lmap.setView(center, zoom);
    pick = null;
    if (lmarker) { lmarker.remove(); lmarker = null; }
    $("#mapTitle").textContent = mapCtx ? "Koppints a túra helyére" : "Koppints a fogás helyére";
    if (own) setPick(own.lat, own.lon);
    else { $("#mapInfo").textContent = "Még nincs kijelölve."; $("#btnMapOk").disabled = true; }
    setTimeout(() => lmap.invalidateSize(), 50);
  }

  function setPick(lat, lon) {
    pick = { lat, lon };
    if (lmarker) lmarker.setLatLng([lat, lon]);
    else lmarker = L.marker([lat, lon]).addTo(lmap);
    $("#mapInfo").textContent = `${lat.toFixed(5)}, ${lon.toFixed(5)}`;
    $("#btnMapOk").disabled = false;
  }

  function mapLocate() {
    if (!("geolocation" in navigator)) return;
    navigator.geolocation.getCurrentPosition(
      (pos) => { setPick(pos.coords.latitude, pos.coords.longitude); lmap.setView([pos.coords.latitude, pos.coords.longitude], 16); },
      () => toast("Nem sikerült pozíciót kapni."),
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 60000 }
    );
  }

  function closeMap(ok) {
    if (ok && pick) {
      if (mapCtx) mapCtx.onPick(pick.lat, pick.lon);
      else setLocation({ lat: pick.lat, lon: pick.lon, acc: null, source: "map" });
    }
    mapCtx = null;
    $("#mapModal").classList.add("hidden");
  }

  // ------------------------------------------------------------------
  // Mentés: új fogás vagy meglévő szerkesztése
  // ------------------------------------------------------------------
  function readForm() {
    const f = $("#catchForm");
    const species = f.species.value.trim();
    const water = f.water.value.trim();
    const pr = parseCatchTime();
    if (pr.error) return { error: pr.error };
    const when = localInputValue(pr.date);
    if (!species || !water || !when) return { error: "A halfaj, az időpont és a vízterület kitöltése kötelező." };
    const caughtAt = new Date(when);
    if (isNaN(caughtAt)) return { error: "Érvénytelen időpont." };
    if (caughtAt.getTime() > Date.now() + 10 * 60 * 1000) return { error: "Az időpont nem lehet a jövőben." };
    const num = (v) => (v === "" || v == null ? null : Number(String(v).replace(",", ".")));
    return {
      data: {
        caught_at: caughtAt.toISOString(),
        species,
        weight_kg: num(f.weight_kg.value),
        length_cm: num(f.length_cm.value),
        water,
        spot: f.spot.value.trim() || null,
        bait: f.bait.value.trim() || null,
        method: f.method.value || null,
        released: f.released.checked,
        note: f.note.value.trim() || null,
        lat: state.gps ? state.gps.lat : null,
        lon: state.gps ? state.gps.lon : null,
        accuracy_m: state.gps && state.gps.acc ? Math.round(state.gps.acc) : null
      }
    };
  }

  async function onSave(ev) {
    ev.preventDefault();
    const msg = $("#saveMsg");
    msg.className = "msg";
    const r = readForm();
    if (r.error) { msg.className = "msg err"; msg.textContent = r.error; return; }
    if (state.editing) return saveEdit(r.data);

    const ctx = state.tripCtx;
    let guest = null;
    if (ctx && ctx.guests) {
      guest = $("#guestSel").value;
      if (!guest) { msg.className = "msg err"; msg.textContent = "Válaszd ki, melyik vendég fogta a halat."; return; }
    }
    const backToTrip = ctx ? ctx.tripId : null;
    const pbMsg = pbMessage(Object.assign({ guest_name: guest, user_id: state.uid }, r.data));
    const item = Object.assign({
      guest_name: guest,
      trip_link: ctx ? ctx.tripId : null,
      client_id: uuid(),
      user_id: state.uid,
      photos: state.photos.map((p) => ({ blob: p.blob })),
      cover_index: Math.max(0, state.photos.findIndex((p) => p.id === state.coverId)),
      photo_path: null,
      weather: undefined,
      created_local: new Date().toISOString()
    }, r.data);

    try {
      await idb.put("outbox", item);
      state.outbox.push(item);
      updateNet();
      fillDatalists();
      toast((pbMsg ? pbMsg + "\n" : "") + (navigator.onLine ? "Mentve, feltöltés folyamatban…" : "Mentve a telefonra. A kapcsolat helyreállása után feltöltődik."), pbMsg ? 6000 : 3000, !!pbMsg);
      resetForm();
      syncOutbox();
      if (backToTrip && trips) { showTab("tabTrips"); trips.open(backToTrip, "catches"); }
      openShare(Object.assign({ _pending: true }, item), true);
    } catch (e) {
      msg.className = "msg err";
      msg.textContent = "A mentés nem sikerült: " + errText(e);
    }
  }

  // Meglévő fogás betöltése szerkesztésre
  async function startEdit(clientId) {
    const pending = state.outbox.find((x) => x.client_id === clientId);
    const synced = state.catches.find((x) => x.client_id === clientId);
    const c = pending || synced;
    if (!c) return;
    const isAdmin = !!(state.me && state.me.is_admin);
    if (c.user_id !== state.uid && !(isAdmin && !pending)) { toast("Csak a saját fogásodat szerkesztheted."); return; }
    if (!pending && !navigator.onLine) { toast("A már feltöltött fogás szerkesztéséhez internetkapcsolat kell."); return; }

    resetForm(true);
    state.editing = { client_id: clientId, pending: !!pending, original: Object.assign({}, c) };
    const f = $("#catchForm");
    f.species.value = c.species || "";
    f.weight_kg.value = c.weight_kg != null ? c.weight_kg : "";
    f.length_cm.value = c.length_cm != null ? c.length_cm : "";
    setCatchTime(new Date(c.caught_at));
    f.water.value = c.water || "";
    f.spot.value = c.spot || "";
    f.bait.value = c.bait || "";
    f.method.value = c.method || "";
    f.released.checked = !!c.released;
    f.note.value = c.note || "";
    setLocation(c.lat != null ? { lat: Number(c.lat), lon: Number(c.lon), acc: c.accuracy_m, source: "saved" } : null);

    // Meglévő fotók betöltése
    if (pending) {
      const blobs = pendingPhotoBlobs(c);
      blobs.forEach((b, i) => {
        const objUrl = URL.createObjectURL(b);
        addFormPhoto({ blob: b, url: objUrl, objUrl });
        if (i === (c.cover_index || 0)) state.coverId = photoSeq;
      });
    } else {
      const paths = catchPhotoPaths(c);
      const urls = await signedUrlsFor(paths);
      const cov = coverPath(c);
      paths.forEach((path) => {
        addFormPhoto({ path, url: urls[path] || null });
        if (path === cov) state.coverId = photoSeq;
      });
    }
    renderPhotoGrid();

    $("#formTitle").textContent = "Fogás szerkesztése";
    $("#btnCancelEdit").classList.remove("hidden");
    $("#btnSave").textContent = "Módosítás mentése";
    f.classList.add("editing");
    const info = $("#editInfo");
    info.textContent = (c.guest_name ? `Vendég fogása: ${c.guest_name} (versenyen kívül) · ` : "") +
      `Rögzítette: ${nameOf(c.user_id)}` + (c.updated_at ? ` · utoljára módosítva: ${dtFmt(c.updated_at)}` : "");
    info.classList.remove("hidden");
    checkLateTime();
    $("#lateWarn").classList.add("hidden");
    showTab("tabNew");
  }

  // ------------------------------------------------------------------
  // Kezdőlap (vezérlőfelület)
  // ------------------------------------------------------------------
  // ------------------------------------------------------------------
  // Visszaszámláló a tervezett túra kezdéséig (7.2): másodpercenként frissül
  // ------------------------------------------------------------------
  function cdText(iso) {
    const left = Math.max(0, Math.floor((new Date(iso).getTime() - Date.now()) / 1000));
    const d = Math.floor(left / 86400), h = Math.floor(left / 3600) % 24, m = Math.floor(left / 60) % 60, sec = left % 60;
    const hms = [h, m, sec].map((x) => String(x).padStart(2, "0")).join(":");
    return { left, text: d ? `${d} nap ${hms}` : hms };
  }
  function countdownHtml(iso, cls) {
    return `<span class="cd${cls ? " " + cls : ""}" data-cd="${esc(iso)}"><span class="cd-l">Indulásig:</span> <span class="cd-v">${esc(cdText(iso).text)}</span></span>`;
  }
  function tickCountdowns() {
    let started = false;
    document.querySelectorAll("[data-cd]").forEach((el) => {
      if (!el.offsetParent) return;          // nem látható nézet
      const c = cdText(el.dataset.cd);
      const v = el.querySelector(".cd-v");
      if (v && v.textContent !== c.text) v.textContent = c.text;
      if (!c.left && !el.dataset.done) { el.dataset.done = "1"; started = true; }
    });
    // Elindult a túra: a kártyák „Most zajlik” állapotra váltanak
    if (started) {
      if (state.tab === "tabHome") renderHome();
      if (state.tab === "tabTrips" && trips) trips.render();
    }
  }

  function renderHome() {
    const box = $("#homeOut");
    if (!box || !state.me) return;
    const all = allEntries();
    const nowY = tzParts(new Date()).y;
    const thisYear = all.filter((c) => yearOf(c.caught_at) === nowY).length;
    const withPh = all.filter((c) => photoCount(c) > 0).length;
    const best = all.reduce((b, c) => (c.weight_kg != null && (!b || Number(c.weight_kg) > Number(b.weight_kg)) ? c : b), null);
    const mine = state.outbox.filter((x) => x.user_id === state.uid).length;
    const ti = trips ? trips.homeInfo() : { active: [], planned: [], total: 0, suggest: 0 };
    const last = all[0];
    const first = (state.me.display_name || "").split(" ").slice(-1)[0];
    const viewer = isViewer();
    const tile = (go, icon, title, sub, fresh, extra) => `<button type="button" class="home-tile${fresh ? " has-news" : ""}" data-go="${go}">
        <span class="ht-icon" aria-hidden="true">${icon}</span><span class="ht-title">${title}</span><span class="ht-sub">${sub}</span>${extra || ""}${fresh ? `<span class="ht-news"><span class="news-dot" aria-hidden="true"></span>${fresh}</span>` : ""}</button>`;
    // Újdonságok a legutóbbi megnyitás óta (mások által)
    const newLog = news && news.ok() ? all.filter((c) => isNewLog(c, true)).length : 0;
    const newGal = news && news.ok() ? all.filter((c) => photoCount(c) > 0 && news.isNew(c.created_at, "gallery", c.user_id, true)).length : 0;
    const tripSub = ti.active.length ? `${ti.active.length} most zajlik` : ti.planned.length ? `${ti.planned.length} tervezett` : `${ti.total} túra`;
    box.innerHTML = `
      <div class="home-hello">Szia${first ? ", " + esc(first) : ""}!</div>
      ${quotes ? quotes.homeHtml() : ""}
      ${viewer ? `<div class="card viewer-note">👀 <b>Nézelődőként</b> látod a naplót: mindent megnézhetsz, de nem módosíthatsz.
          <small>Hozzáférés: ${state.me.viewer_until ? "lejár " + esc(dtFmt(state.me.viewer_until)) + "-kor" : "korlátlan"}</small></div>`
        : `<button type="button" class="home-new" data-go="tabNew"><span aria-hidden="true">＋</span> Új fogás rögzítése</button>`}
      ${inst ? inst.cardHtml() : ""}
      ${admin ? admin.homeHtml() : ""}
      ${cel ? cel.homeHtml() : ""}
      ${mine ? `<button type="button" class="card home-alert" data-home-sync>⟳ ${mine} fogás feltöltésre vár – koppints a küldéshez</button>` : ""}
      <div class="home-grid">
        ${tile("tabLog", "☰", "Napló", `${all.length} fogás`, newLog ? `${newLog} új fogás` : "")}
        ${tile("records", "🏆", "Rekordok", best ? `${esc(best.species)} ${esc(numFmt(best.weight_kg))} kg` : "rangsorok")}
        ${tile("tabTrips", "⚑", "Túrák", tripSub + (ti.suggest ? ` · ${ti.suggest} javaslat` : ""), ti.news ? `${ti.news} túrán újdonság` : "",
          ti.planned.length ? countdownHtml(ti.planned[0].start_at, "tile") : "")}
        ${tile("tabGallery", "▦", "Galéria", `${withPh} fotós fogás`, newGal ? `${newGal} új` : "")}
        ${tile("tabStats", "▤", "Összesítők", `idén ${thisYear} fogás`)}
        ${viewer ? "" : tile("tabFamily", "👪", "Nézelődők", "meghívás, hozzáférések")}
        ${tile("menu", "⚙", "Beállítások", viewer ? "név, kilépés" : "értesítés, név, kilépés")}
      </div>
      ${ti.active.concat(ti.planned.slice(0, 1)).map((t) => `
        <button type="button" class="card home-trip" data-trip-open="${esc(t.id)}">
          <span class="ht-kicker">${t._status === "active" ? "Most zajlik" : "Következő túra"}</span>
          <span class="ht-title">${esc(t.title)}</span>
          <span class="ht-sub">${esc(t.water)} · ${esc(t._range)}${t._mine ? ` · Te: ${esc(t._mine)}` : t._status === "planned" ? " · még nem jelezted" : ""}</span>
        </button>`).join("")}
      ${last ? `<button type="button" class="card home-last" data-home-last="${esc(last.client_id)}">
          <span class="ht-kicker">Legutóbbi fogás</span>
          <span class="ht-title">${esc(last.species)}${last.weight_kg != null ? ` – ${esc(numFmt(last.weight_kg))} kg` : ""}</span>
          <span class="ht-sub">${esc(nameOf(last.user_id))} · ${esc(last.water)} · ${esc(dtFmt(last.caught_at))}</span>
        </button>` : ""}`;
  }

  function goHome() {
    try {
      if (history.state && history.state.tab && history.state.tab !== "tabHome") { history.back(); return; }
    } catch (_) { /* nem elérhető */ }
    showTab("tabHome");
  }

  function onHomeGo(go) {
    if (go === "menu") { $("#menuPanel").classList.remove("hidden"); return; }
    if (go === "records") { if (logView() !== "records") state.lastListView = logView(); state.logView = "records"; try { localStorage.setItem("logView", "records"); } catch (_) { /* nincs tároló */ } showTab("tabLog"); return; }
    if (go === "tabLog" && logView() === "records") { state.logView = state.lastListView || "detail"; try { localStorage.setItem("logView", state.logView); } catch (_) { /* nincs tároló */ } }
    showTab(go);
  }

  // ------------------------------------------------------------------
  // A fotó készítésének ideje a JPEG EXIF adataiból (DateTimeOriginal)
  // ------------------------------------------------------------------
  async function exifDate(file) {
    const buf = await file.slice(0, 256 * 1024).arrayBuffer();
    const v = new DataView(buf);
    if (v.byteLength < 4 || v.getUint16(0) !== 0xFFD8) return null;
    let o = 2;
    while (o + 10 < v.byteLength) {
      const m = v.getUint16(o), len = v.getUint16(o + 2);
      if (m === 0xFFE1 && v.getUint32(o + 4) === 0x45786966) return exifTiffDate(v, o + 10);
      if ((m & 0xFF00) !== 0xFF00 || m === 0xFFDA) break;
      o += 2 + len;
    }
    return null;
  }
  function exifTiffDate(v, t) {
    const le = v.getUint16(t) === 0x4949;
    const u16 = (p) => v.getUint16(p, le), u32 = (p) => v.getUint32(p, le);
    const SIZE = [0, 1, 1, 2, 4, 8, 1, 1, 2, 4, 8, 4, 8];
    const ifd = (off) => {
      const out = {};
      if (t + off + 2 > v.byteLength) return out;
      const n = u16(t + off);
      for (let i = 0; i < n; i++) {
        const e = t + off + 2 + i * 12;
        if (e + 12 > v.byteLength) break;
        const type = u16(e + 2), cnt = u32(e + 4);
        out[u16(e)] = { cnt, at: cnt * (SIZE[type] || 1) > 4 ? t + u32(e + 8) : e + 8 };
      }
      return out;
    };
    const str = (en) => { let r = ""; for (let i = 0; i < en.cnt - 1 && en.at + i < v.byteLength; i++) r += String.fromCharCode(v.getUint8(en.at + i)); return r; };
    const i0 = ifd(u32(t + 4));
    let raw = null;
    if (i0[0x8769]) { const ex = ifd(u32(i0[0x8769].at)); const en = ex[0x9003] || ex[0x9004]; if (en) raw = str(en); }
    if (!raw && i0[0x0132]) raw = str(i0[0x0132]);
    const m = raw && raw.match(/^(\d{4}):(\d{2}):(\d{2})[ T](\d{2}):(\d{2}):(\d{2})/);
    if (!m) return null;
    const d = new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +m[6]); // a fényképezőgép helyi ideje
    if (isNaN(d) || d.getFullYear() < 1995 || d.getTime() > Date.now() + 86400000) return null;
    return d;
  }

  // Fogás rögzítése egy túrából (saját vagy vendég fogása)
  function startCatchForTrip(t, guests) {
    resetForm(true);
    const f = $("#catchForm");
    f.water.value = t.water || "";
    const now = Date.now(), s = new Date(t.start_at).getTime(), e = new Date(t.end_at).getTime();
    if (now < s || now > e) setCatchTime(new Date(s));
    if (!isRecentTime() && t.lat != null) setLocation({ lat: Number(t.lat), lon: Number(t.lon), acc: null, source: "list" });
    state.tripCtx = { tripId: t.id, guests: guests && guests.length ? guests : null };
    $("#tripCtxTitle").textContent = `⚑ ${t.title}`;
    $("#guestField").classList.toggle("hidden", !state.tripCtx.guests);
    $("#guestSel").innerHTML = state.tripCtx.guests
      ? `<option value="">— válaszd ki —</option>` + guests.map((g) => `<option value="${esc(g)}">${esc(g)}</option>`).join("") : "";
    if (state.tripCtx.guests && guests.length === 1) $("#guestSel").value = guests[0];
    $("#tripCtxHint").textContent = state.tripCtx.guests
      ? "Vendégfogás: versenyen kívüli, csak a túranaplóban jelenik meg."
      : (now < s || now > e ? "Az időpontot a túra kezdésére állítottam – írd át a fogás valódi idejére." : "A fogás ehhez a túrához kerül.");
    $("#tripCtx").classList.remove("hidden");
    showTab("tabNew");
  }

  function cancelEdit() {
    resetForm();
    showTab("tabLog");
  }

  async function saveEdit(data) {
    const ed = state.editing;
    const o = ed.original;
    const msg = $("#saveMsg");
    const btn = $("#btnSave");
    const sameTime = new Date(o.caught_at).getTime() === new Date(data.caught_at).getTime();
    const samePlace = (o.lat == null && data.lat == null) ||
      (o.lat != null && data.lat != null && Math.abs(o.lat - data.lat) < 1e-6 && Math.abs(o.lon - data.lon) < 1e-6);
    const weatherStale = !(sameTime && samePlace);

    btn.disabled = true;
    msg.className = "msg"; msg.textContent = "Mentés…";
    try {
      if (ed.pending) {
        // Még fel nem töltött fogás: helyben módosítjuk, a feltöltés később történik
        const item = state.outbox.find((x) => x.client_id === ed.client_id);
        if (!item) throw new Error("A fogás közben feltöltődött. Nyisd meg újra a szerkesztést a naplóból.");
        Object.assign(item, data);
        delete item.photo;
        item.photos = state.photos.map((p) => ({ blob: p.blob }));
        item.cover_index = Math.max(0, state.photos.findIndex((p) => p.id === state.coverId));
        item.photo_path = null;
        if (weatherStale) item.weather = undefined;
        await idb.put("outbox", item);
        toast("Módosítás mentve.");
        resetForm();
        showTab("tabLog");
        syncOutbox();
        return;
      }

      if (!navigator.onLine) throw new Error("Nincs internetkapcsolat. A módosítás nem került mentésre.");
      const row = Object.assign({}, data);
      if (weatherStale) {
        row.weather = null;
        if (row.lat != null) {
          try { row.weather = await fetchWeather(row.lat, row.lon, row.caught_at); }
          catch (we) { console.warn(we); toast("Az időjárási adat most nem kérhető le; a fogás időjárás nélkül módosult."); }
        }
      }
      // Fotók: az újakat feltöltjük, a sorrend és a listakép az űrlap szerint
      const stamp = Date.now();
      const finalPaths = [];
      let coverP = null;
      for (let i = 0; i < state.photos.length; i++) {
        const ph = state.photos[i];
        let path = ph.path;
        if (!path) {
          path = await uploadPhoto(ph.blob, `${o.user_id}/${o.client_id}-${stamp}-${i}.${extOf(ph.blob.type)}`);
          ph.path = path;
        }
        finalPaths.push(path);
        if (ph.id === state.coverId) coverP = path;
      }
      row.photos = finalPaths;
      row.photo_path = coverP || finalPaths[0] || null;
      const removedPaths = catchPhotoPaths(o).filter((x) => !finalPaths.includes(x));
      row.updated_at = new Date().toISOString();
      row.updated_by = state.uid;

      const doUpdate = () => state.sb.from("catches").update(row).eq("client_id", o.client_id).select("client_id");
      let { data: upd, error } = await doUpdate();
      if (missingCol(error, "photos")) { delete row.photos; ({ data: upd, error } = await doUpdate()); }
      if (missingCol(error, "updated_(at|by)")) {
        // A 2. verziós adatbázis-frissítés még nem futott le: módosítás a régi oszlopokkal
        delete row.updated_at; delete row.updated_by;
        ({ data: upd, error } = await doUpdate());
      }
      if (error) throw error;
      if (!upd || !upd.length) throw new Error("Nincs jogosultságod ennek a fogásnak a módosításához.");
      if (removedPaths.length) state.sb.storage.from("photos").remove(removedPaths).catch(() => {});
      toast("Módosítás mentve.");
      resetForm();
      await refreshData();
      showTab("tabLog");
    } catch (e) {
      msg.className = "msg err";
      msg.textContent = "A módosítás nem sikerült: " + errText(e);
    } finally {
      btn.disabled = false;
    }
  }

  // ------------------------------------------------------------------
  // Időjárás (Open-Meteo)
  // ------------------------------------------------------------------
  async function fetchWeather(lat, lon, iso) {
    const t = new Date(new Date(iso).getTime() + 30 * 60 * 1000); // legközelebbi egész óra
    const p = tzParts(t);
    const day = `${p.y}-${p.m}-${p.d}`;
    const prev = tzParts(new Date(t.getTime() - 24 * 3600 * 1000));
    const prevDay = `${prev.y}-${prev.m}-${prev.d}`;
    const ageDays = (Date.now() - t.getTime()) / 86400000;
    const base = ageDays > 80 ? "https://archive-api.open-meteo.com/v1/archive" : "https://api.open-meteo.com/v1/forecast";
    const params = new URLSearchParams({
      latitude: lat.toFixed(4),
      longitude: lon.toFixed(4),
      hourly: "temperature_2m,pressure_msl,wind_speed_10m,wind_direction_10m,cloud_cover,precipitation,weather_code",
      timezone: TZ,
      wind_speed_unit: "kmh",
      start_date: prevDay,
      end_date: day
    });
    const res = await fetch(`${base}?${params}`);
    if (!res.ok) throw new Error("Időjárás-lekérés hiba: " + res.status);
    const j = await res.json();
    const H = j.hourly;
    const key = `${day}T${p.h}:00`;
    const i = H && H.time ? H.time.indexOf(key) : -1;
    if (i < 0) throw new Error("Nincs időjárási adat erre az időpontra.");
    const val = (arr, k) => (arr && arr[k] != null ? arr[k] : null);
    const pNow = val(H.pressure_msl, i);
    const p3 = i >= 3 ? val(H.pressure_msl, i - 3) : null;
    const code = val(H.weather_code, i);
    return {
      source: "Open-Meteo",
      time: key,
      temp_c: val(H.temperature_2m, i),
      pressure_hpa: pNow,
      pressure_trend_3h: pNow != null && p3 != null ? Math.round((pNow - p3) * 10) / 10 : null,
      wind_kmh: val(H.wind_speed_10m, i),
      wind_dir_deg: val(H.wind_direction_10m, i),
      cloud_pct: val(H.cloud_cover, i),
      precip_mm: val(H.precipitation, i),
      code,
      desc: code != null ? (WMO[code] || `kód ${code}`) : null
    };
  }

  const WIND_DIRS = ["É", "ÉÉK", "ÉK", "KÉK", "K", "KDK", "DK", "DDK", "D", "DDNy", "DNy", "NyDNy", "Ny", "NyÉNy", "ÉNy", "ÉÉNy"];
  const windDir = (deg) => (deg == null ? "" : WIND_DIRS[Math.round(deg / 22.5) % 16]);

  // Holdfázis számítása (Meeus-féle közelítés a legközelebbi újholdra korrekciókkal)
  function moonInfo(date) {
    const SYN = 29.530588853;
    const jd = date.getTime() / 86400000 + 2440587.5;
    const rad = Math.PI / 180;
    // Meeus 49. fejezet: k-adik újhold ideje
    function newMoonJD(k) {
      const T = k / 1236.85;
      let JDE = 2451550.09766 + 29.530588861 * k + 0.00015437 * T * T - 0.00000015 * T * T * T + 0.00000000073 * T ** 4;
      const E = 1 - 0.002516 * T - 0.0000074 * T * T;
      const M = (2.5534 + 29.1053567 * k - 0.0000014 * T * T) * rad;
      const Mp = (201.5643 + 385.81693528 * k + 0.0107582 * T * T + 0.00001238 * T ** 3) * rad;
      const F = (160.7108 + 390.67050284 * k - 0.0016118 * T * T) * rad;
      const Om = (124.7746 - 1.56375588 * k + 0.0020672 * T * T) * rad;
      JDE += -0.4072 * Math.sin(Mp) + 0.17241 * E * Math.sin(M) + 0.01608 * Math.sin(2 * Mp) + 0.01039 * Math.sin(2 * F)
        + 0.00739 * E * Math.sin(Mp - M) - 0.00514 * E * Math.sin(Mp + M) + 0.00208 * E * E * Math.sin(2 * M)
        - 0.00111 * Math.sin(Mp - 2 * F) - 0.00057 * Math.sin(Mp + 2 * F) + 0.00056 * E * Math.sin(2 * Mp + M)
        - 0.00042 * Math.sin(3 * Mp) + 0.00042 * E * Math.sin(M + 2 * F) + 0.00038 * E * Math.sin(M - 2 * F)
        - 0.00024 * E * Math.sin(2 * Mp - M) - 0.00017 * Math.sin(Om);
      return JDE - 69 / 86400; // TT → UT (kb.)
    }
    let k = Math.floor((jd - 2451550.09766) / SYN);
    let nm = newMoonJD(k);
    if (nm > jd) { k--; nm = newMoonJD(k); }
    let next = newMoonJD(k + 1);
    if (next <= jd) { k++; nm = next; next = newMoonJD(k + 1); }
    const age = jd - nm;
    const len = next - nm;
    const f = age / len;
    const illum = Math.round((1 - Math.cos(2 * Math.PI * f)) / 2 * 100);
    const names = ["Újhold", "Növekvő sarló", "Első negyed", "Növekvő hold", "Telihold", "Fogyó hold", "Utolsó negyed", "Fogyó sarló"];
    const icons = ["🌑", "🌒", "🌓", "🌔", "🌕", "🌖", "🌗", "🌘"];
    const idx = Math.floor(f * 8 + 0.5) % 8;
    return { name: names[idx], icon: icons[idx], age_days: Math.round(age * 10) / 10, illum_pct: illum, idx };
  }
  // ------------------------------------------------------------------
  // Névnap: a nap első (fő) névnapja a magyar naptár szerint
  // Forrás: több független névnaptár összevetése (2026.10.12.).
  // Szökőévben február 24. a szökőnap; Mátyás 25-re, a többi egy nappal később kerül.
  // ------------------------------------------------------------------
  const NEVNAPOK = [
    ["Fruzsina", "Ábel", "Genovéva", "Titusz", "Simon", "Boldizsár", "Attila", "Gyöngyvér", "Marcell", "Melánia", "Ágota", "Ernő", "Veronika", "Bódog", "Lóránt", "Gusztáv", "Antal", "Piroska", "Sára", "Fábián", "Ágnes", "Vince", "Zelma", "Timót", "Pál", "Vanda", "Angelika", "Károly", "Adél", "Martina", "Marcella"],
    ["Ignác", "Karolina", "Balázs", "Ráhel", "Ágota", "Dorottya", "Tódor", "Aranka", "Abigél", "Elvira", "Bertold", "Lívia", "Ella", "Bálint", "Kolos", "Julianna", "Donát", "Bernadett", "Zsuzsanna", "Aladár", "Eleonóra", "Gerzson", "Alfréd", "Mátyás", "Géza", "Edina", "Ákos", "Elemér"],
    ["Albin", "Lujza", "Kornélia", "Kázmér", "Adorján", "Leonóra", "Tamás", "Zoltán", "Franciska", "Ildikó", "Szilárd", "Gergely", "Krisztián", "Matild", "Kristóf", "Henrietta", "Gertrúd", "Sándor", "József", "Klaudia", "Benedek", "Beáta", "Emőke", "Gábor", "Irén", "Emánuel", "Hajnalka", "Gedeon", "Auguszta", "Zalán", "Árpád"],
    ["Hugó", "Áron", "Buda", "Izidor", "Vince", "Vilmos", "Herman", "Dénes", "Erhard", "Zsolt", "Leó", "Gyula", "Ida", "Tibor", "Anasztázia", "Csongor", "Rudolf", "Andrea", "Emma", "Tivadar", "Konrád", "Csilla", "Béla", "György", "Márk", "Ervin", "Zita", "Valéria", "Péter", "Katalin"],
    ["Fülöp", "Zsigmond", "Tímea", "Mónika", "Györgyi", "Ivett", "Gizella", "Mihály", "Gergely", "Ármin", "Ferenc", "Pongrác", "Szervác", "Bonifác", "Zsófia", "Mózes", "Paszkál", "Erik", "Ivó", "Bernát", "Konstantin", "Júlia", "Dezső", "Eszter", "Orbán", "Fülöp", "Hella", "Emil", "Magdolna", "Janka", "Angéla"],
    ["Tünde", "Kármen", "Klotild", "Bulcsú", "Fatime", "Norbert", "Róbert", "Medárd", "Félix", "Margit", "Barnabás", "Villő", "Antal", "Vazul", "Jolán", "Jusztin", "Laura", "Arnold", "Gyárfás", "Rafael", "Alajos", "Paulina", "Zoltán", "Iván", "Vilmos", "János", "László", "Levente", "Péter", "Pál"],
    ["Tihamér", "Ottó", "Kornél", "Ulrik", "Emese", "Csaba", "Apollónia", "Ellák", "Lukrécia", "Amália", "Nóra", "Izabella", "Jenő", "Örs", "Henrik", "Valter", "Endre", "Frigyes", "Emília", "Illés", "Dániel", "Magdolna", "Lenke", "Kinga", "Kristóf", "Anna", "Olga", "Szabolcs", "Márta", "Judit", "Oszkár"],
    ["Boglárka", "Lehel", "Hermina", "Domonkos", "Krisztina", "Berta", "Ibolya", "László", "Emőd", "Lőrinc", "Zsuzsanna", "Klára", "Ipoly", "Marcell", "Mária", "Ábrahám", "Jácint", "Ilona", "Huba", "István", "Sámuel", "Menyhért", "Bence", "Bertalan", "Lajos", "Izsó", "Gáspár", "Ágoston", "Beatrix", "Rózsa", "Erika"],
    ["Egyed", "Rebeka", "Hilda", "Rozália", "Viktor", "Zakariás", "Regina", "Mária", "Ádám", "Nikolett", "Teodóra", "Mária", "Kornél", "Szeréna", "Enikő", "Edit", "Zsófia", "Diána", "Vilhelmina", "Friderika", "Máté", "Móric", "Tekla", "Gellért", "Eufrozina", "Jusztina", "Adalbert", "Vencel", "Mihály", "Jeromos"],
    ["Malvin", "Petra", "Helga", "Ferenc", "Aurél", "Brúnó", "Amália", "Koppány", "Dénes", "Gedeon", "Brigitta", "Miksa", "Kálmán", "Helén", "Teréz", "Gál", "Hedvig", "Lukács", "Nándor", "Vendel", "Orsolya", "Előd", "Gyöngyi", "Salamon", "Blanka", "Dömötör", "Szabina", "Simon", "Nárcisz", "Alfonz", "Farkas"],
    ["Marianna", "Achilles", "Győző", "Károly", "Imre", "Lénárd", "Rezső", "Zsombor", "Tivadar", "Réka", "Márton", "Jónás", "Szilvia", "Aliz", "Albert", "Ödön", "Hortenzia", "Jenő", "Erzsébet", "Jolán", "Olivér", "Cecília", "Kelemen", "Emma", "Katalin", "Virág", "Virgil", "Stefánia", "Taksony", "András"],
    ["Elza", "Melinda", "Ferenc", "Borbála", "Vilma", "Miklós", "Ambrus", "Mária", "Natália", "Judit", "Árpád", "Gabriella", "Luca", "Szilárda", "Valér", "Etelka", "Lázár", "Auguszta", "Viola", "Teofil", "Tamás", "Zénó", "Viktória", "Ádám", "Eugénia", "István", "János", "Kamilla", "Tamás", "Dávid", "Szilveszter"]
  ];

  function nameDayOf(date) {
    const p = tzParts(date);
    const y = Number(p.y), m = Number(p.m), d = Number(p.d);
    const leap = (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0;
    if (m === 2 && leap) {
      if (d === 24) return { name: null, note: "szökőnap" };
      if (d >= 25) return { name: NEVNAPOK[1][d - 2] };
    }
    const name = (NEVNAPOK[m - 1] || [])[d - 1];
    return { name: name || null };
  }
  function nameDayText(date) {
    const n = nameDayOf(date);
    return n.name ? n.name : (n.note === "szökőnap" ? "szökőnap" : "–");
  }

  const MOON_NAMES = ["Újhold", "Növekvő sarló", "Első negyed", "Növekvő hold", "Telihold", "Fogyó hold", "Utolsó negyed", "Fogyó sarló"];

  function weatherLine(w) {
    if (!w) return "";
    const parts = [];
    if (w.desc) parts.push(w.desc);
    if (w.temp_c != null) parts.push(`${numFmt(w.temp_c, 1)} °C`);
    if (w.pressure_hpa != null) {
      let s = `légnyomás ${numFmt(w.pressure_hpa, 0)} hPa`;
      if (w.pressure_trend_3h != null) {
        const t = w.pressure_trend_3h;
        s += t > 0.5 ? " ↑" : t < -0.5 ? " ↓" : " →";
      }
      parts.push(s);
    }
    if (w.wind_kmh != null) parts.push(`szél ${windDir(w.wind_dir_deg)} ${numFmt(w.wind_kmh, 0)} km/h`);
    if (w.cloud_pct != null) parts.push(`felhő ${numFmt(w.cloud_pct, 0)}%`);
    if (w.precip_mm) parts.push(`csapadék ${numFmt(w.precip_mm, 1)} mm`);
    return parts.join(" · ");
  }

  // ------------------------------------------------------------------
  // Szinkronizálás
  // ------------------------------------------------------------------
  async function syncOutbox() {
    if (state.syncing || !navigator.onLine || !state.sb || !state.uid) return;
    const { data } = await state.sb.auth.getSession().catch(() => ({ data: {} }));
    if (!data || !data.session) return;
    const items = state.outbox.filter((x) => x.user_id === state.uid);
    if (!items.length) return;

    state.syncing = true;
    updateNet();
    let ok = 0, failed = 0, lastErr = null;

    for (const item of items) {
      try {
        // 1. Fotók feltöltése (a már feltöltöttek nem mennek fel újra)
        if (item.photo && !item.photos) { item.photos = [{ blob: item.photo }]; item.cover_index = 0; delete item.photo; }
        const phs = item.photos || [];
        for (let i = 0; i < phs.length; i++) {
          if (!phs[i].path) {
            phs[i].path = await uploadPhoto(phs[i].blob, `${state.uid}/${item.client_id}-${i}.${extOf(phs[i].blob.type)}`);
            await idb.put("outbox", item);
          }
        }
        const paths = phs.map((x) => x.path);
        item.photo_path = paths[Math.min(item.cover_index || 0, Math.max(0, paths.length - 1))] || null;
        // 2. Időjárás (ha van pozíció). Ha nem sikerül, a fogás attól még felkerül.
        if (item.weather === undefined) {
          if (item.lat != null && item.lon != null) {
            try { item.weather = await fetchWeather(item.lat, item.lon, item.caught_at); }
            catch (we) { console.warn(we); item.weather = null; }
          } else {
            item.weather = null;
          }
          await idb.put("outbox", item);
        }
        // 3. Fogás rögzítése (a client_id miatt duplán nem kerülhet fel)
        const row = {
          client_id: item.client_id,
          user_id: item.user_id,
          caught_at: item.caught_at,
          species: item.species,
          weight_kg: item.weight_kg,
          length_cm: item.length_cm,
          water: item.water,
          spot: item.spot,
          bait: item.bait,
          method: item.method,
          released: item.released,
          note: item.note,
          lat: item.lat,
          lon: item.lon,
          accuracy_m: item.accuracy_m,
          photo_path: item.photo_path,
          photos: paths.length ? paths : null,
          weather: item.weather
        };
        if (item.guest_name) row.guest_name = item.guest_name;
        const doUpsert = () => state.sb.from("catches").upsert(row, { onConflict: "client_id", ignoreDuplicates: true });
        let { error } = await doUpsert();
        if (missingCol(error, "photos")) { delete row.photos; ({ error } = await doUpsert()); }
        if (error) throw error;
        // Túrából rögzített fogás: kézi hozzárendelés is (ha a vízterület neve eltérne)
        if (item.trip_link) {
          const lr = await state.sb.from("trip_catch_links")
            .upsert({ trip_id: item.trip_link, client_id: item.client_id, included: true }, { onConflict: "trip_id,client_id" });
          if (lr.error) console.warn("Túra-hozzárendelés:", lr.error);
        }
        notifyNewCatch(item.client_id);

        await idb.del("outbox", item.client_id);
        state.outbox = state.outbox.filter((x) => x.client_id !== item.client_id);
        ok++;
      } catch (e) {
        failed++; lastErr = e;
        console.warn("Szinkron hiba:", e);
      }
      updateNet();
    }

    state.syncing = false;
    updateNet();
    if (ok) { toast(`${ok} fogás feltöltve.`); await refreshData(); }
    if (failed) toast(`${failed} fogás feltöltése nem sikerült: ${errText(lastErr)}. Később újrapróbálom.`, 5000);
  }

  // ------------------------------------------------------------------
  // Napló
  // ------------------------------------------------------------------
  // Minden fogás, a vendégek (versenyen kívüli) fogásaival együtt – a túranaplóhoz
  function everyEntry() {
    const pending = state.outbox
      .filter((x) => x.user_id === state.uid)
      .map((x) => Object.assign({}, x, { _pending: true }));
    const synced = state.catches.filter((c) => !pending.some((p) => p.client_id === c.client_id));
    return pending.concat(synced).sort((a, b) => (a.caught_at < b.caught_at ? 1 : -1));
  }
  // A napló, a galéria, az összesítők és az export: vendégfogások nélkül
  function allEntries() {
    return everyEntry().filter((c) => !c.guest_name);
  }

  const nameOf = (uid) => (state.profiles[uid] && state.profiles[uid].display_name) ||
    (uid === state.uid && state.me ? state.me.display_name : "Ismeretlen");
  // A fogó neve: tag vagy vendég
  const anglerOf = (c) => (c.guest_name ? `${c.guest_name} (vendég)` : nameOf(c.user_id));

  function fillSelect(sel, values, allLabel, keep = true) {
    const cur = sel.value;
    sel.innerHTML = `<option value="">${esc(allLabel)}</option>` +
      values.map((v) => `<option value="${esc(v.value)}">${esc(v.label)}</option>`).join("");
    if (keep && values.some((v) => v.value === cur)) sel.value = cur;
  }

  function yearOptions(entries) {
    return Array.from(new Set(entries.map((c) => yearOf(c.caught_at)))).sort().reverse()
      .map((y) => ({ value: y, label: y }));
  }

  function filteredEntries() {
    const y = $("#fYear").value, u = $("#fUser").value, w = $("#fWater").value, s = $("#fSpecies").value;
    const r = dayRange($("#fFrom").value, $("#fTo").value);
    return allEntries().filter((c) =>
      (!y || yearOf(c.caught_at) === y) &&
      (!u || c.user_id === u) &&
      (!w || c.water === w) &&
      (!s || c.species === s) &&
      inDayRange(c, r)).sort(logSorter());
  }

  // Rendezés (egyszerre egy szempont); egyezésnél az idő dönt (legújabb elöl), súly nélküli fogás a végén
  function logSorter() {
    const mode = $("#fSort").value || "time_desc";
    const t = (c) => c.caught_at;
    const byTime = (a, b) => (t(a) < t(b) ? 1 : t(a) > t(b) ? -1 : 0);
    const txt = (a, b) => a.localeCompare(b, "hu", { sensitivity: "base" });
    if (mode === "time_asc") return (a, b) => -byTime(a, b);
    if (mode === "kg_desc" || mode === "kg_asc") {
      const dir = mode === "kg_desc" ? -1 : 1;
      return (a, b) => {
        const x = a.weight_kg == null ? null : Number(a.weight_kg), y = b.weight_kg == null ? null : Number(b.weight_kg);
        if (x == null && y == null) return byTime(a, b);
        if (x == null) return 1;
        if (y == null) return -1;
        return x !== y ? dir * (x - y) : byTime(a, b);
      };
    }
    if (mode === "angler") return (a, b) => txt(anglerOf(a), anglerOf(b)) || byTime(a, b);
    if (mode === "water") return (a, b) => txt(a.water || "", b.water || "") || byTime(a, b);
    return byTime;
  }

  // ------------------------------------------------------------------
  // Nap / időszak szűrő (Napló, Rekordok). Egy nap: csak a „tól” mező; időszak: mindkettő.
  // ------------------------------------------------------------------
  function parseDay(str) {
    const m = String(str || "").trim().match(/^(\d{4})[.\-\/ ]?(\d{1,2})[.\-\/ ]?(\d{1,2})\.?$/);
    if (!m) return null;
    const d = new Date(+m[1], +m[2] - 1, +m[3]);
    if (d.getFullYear() !== +m[1] || d.getMonth() !== +m[2] - 1 || d.getDate() !== +m[3]) return null;
    return `${m[1]}-${pad2(+m[2])}-${pad2(+m[3])}`;
  }
  // {from, to} napkulcsok ("ÉÉÉÉ-HH-NN"), vagy null, ha nincs szűrés; {bad:true}, ha hibás
  function dayRange(fromStr, toStr) {
    const fs = String(fromStr || "").trim(), ts = String(toStr || "").trim();
    if (!fs && !ts) return null;
    const a = fs ? parseDay(fs) : null, b = ts ? parseDay(ts) : null;
    if ((fs && !a) || (ts && !b)) return { bad: true };
    let from = a || b, to = b || a;
    if (from > to) [from, to] = [to, from];
    return { from, to };
  }
  const dayKeyOf = (iso) => { const p = tzParts(new Date(iso)); return `${p.y}-${p.m}-${p.d}`; };
  const inDayRange = (c, r) => !r || r.bad || (dayKeyOf(c.caught_at) >= r.from && dayKeyOf(c.caught_at) <= r.to);
  const dayInput = (key) => key.replace(/-/g, ".");
  function quickRange(code) {
    const now = new Date();
    const key = (d) => `${d.getFullYear()}-${pad2(d.getMonth() + 1)}-${pad2(d.getDate())}`;
    const minus = (n) => { const d = new Date(now); d.setDate(d.getDate() - n); return d; };
    if (code === "today") return { from: key(now), to: key(now) };
    if (code === "yesterday") return { from: key(minus(1)), to: key(minus(1)) };
    if (code === "7") return { from: key(minus(6)), to: key(now) };
    if (code === "month") return { from: key(new Date(now.getFullYear(), now.getMonth(), 1)), to: key(now) };
    return null;
  }
  function formatDayInput(el) {
    let v = el.value.replace(/[^\d]/g, "").slice(0, 8);
    if (v.length > 6) v = `${v.slice(0, 4)}.${v.slice(4, 6)}.${v.slice(6)}`;
    else if (v.length > 4) v = `${v.slice(0, 4)}.${v.slice(4)}`;
    el.value = v;
  }
  function onLogDateInput(e) {
    formatDayInput(e.target);
    const v = e.target.value;
    if (v.length === 0 || v.length === 10) applyLogDate();
  }
  function applyLogDate() {
    const r = dayRange($("#fFrom").value, $("#fTo").value);
    $("#fFrom").classList.toggle("bad", !!(r && r.bad) && !!$("#fFrom").value && !parseDay($("#fFrom").value));
    $("#fTo").classList.toggle("bad", !!(r && r.bad) && !!$("#fTo").value && !parseDay($("#fTo").value));
    $("#fDateClear").classList.toggle("hidden", !r);
    if (r && r.bad) return;
    renderLog();
  }
  function setLogDate(r) {
    $("#fFrom").value = r ? dayInput(r.from) : "";
    $("#fTo").value = r && r.to !== r.from ? dayInput(r.to) : "";
    applyLogDate();
  }

  async function signedUrl(path) {
    const r = await signedUrlsFor([path]);
    return r[path] || null;
  }

  // Több fotó aláírt címe egyszerre (gyorsítótárral, 50 percig)
  async function signedUrlsFor(paths) {
    const out = {}, need = [];
    const now = Date.now();
    Array.from(new Set(paths.filter(Boolean))).forEach((p) => {
      const hit = state.signedUrls[p];
      if (hit && hit.exp > now) out[p] = hit.url; else need.push(p);
    });
    if (!need.length || !navigator.onLine || !state.sb) return out;
    const bucket = state.sb.storage.from("photos");
    try {
      if (bucket.createSignedUrls) {
        for (let i = 0; i < need.length; i += 100) {
          const { data } = await bucket.createSignedUrls(need.slice(i, i + 100), 3600);
          (data || []).forEach((d) => { if (d && d.signedUrl && d.path) { out[d.path] = d.signedUrl; state.signedUrls[d.path] = { url: d.signedUrl, exp: now + 50 * 60000 }; } });
        }
      } else {
        await Promise.all(need.map(async (p) => {
          const { data } = await bucket.createSignedUrl(p, 3600);
          if (data && data.signedUrl) { out[p] = data.signedUrl; state.signedUrls[p] = { url: data.signedUrl, exp: now + 50 * 60000 }; }
        }));
      }
    } catch (e) { console.warn("Fotócímek lekérése sikertelen:", e); }
    return out;
  }

  // Egy fogás összes fotójának címe (helyi vagy aláírt), a listakép elöl
  async function photoUrlsOf(c) {
    if (c._pending) {
      const blobs = pendingPhotoBlobs(c);
      const ci = Math.min(c.cover_index || 0, Math.max(0, blobs.length - 1));
      const ordered = blobs.length ? [blobs[ci]].concat(blobs.filter((_, i) => i !== ci)) : [];
      return ordered.map((b) => URL.createObjectURL(b));
    }
    const paths = catchPhotoPaths(c);
    const cov = coverPath(c);
    const ordered = cov ? [cov].concat(paths.filter((x) => x !== cov)) : paths;
    const urls = await signedUrlsFor(ordered);
    return ordered.map((p) => urls[p]).filter(Boolean);
  }

  // ------------------------------------------------------------------
  // Fotónéző (lapozható)
  // ------------------------------------------------------------------
  const viewer = { urls: [], i: 0, caption: "" };
  function openViewer(urls, i, caption) {
    if (!urls.length) return;
    viewer.urls = urls; viewer.i = i || 0; viewer.caption = caption || "";
    showViewer();
    $("#photoModal").classList.remove("hidden");
  }
  function showViewer() {
    const n = viewer.urls.length;
    $("#photoModalImg").src = viewer.urls[viewer.i];
    const cap = Array.isArray(viewer.caption) ? viewer.caption[viewer.i] || "" : viewer.caption;
    $("#viewerCaption").textContent = cap + (n > 1 ? `  (${viewer.i + 1}/${n})` : "");
    $("#viewerPrev").classList.toggle("hidden", n < 2);
    $("#viewerNext").classList.toggle("hidden", n < 2);
  }
  function stepViewer(d) {
    const n = viewer.urls.length;
    if (n < 2) return;
    viewer.i = (viewer.i + d + n) % n;
    showViewer();
  }
  function captionOf(c) {
    const w = c.weight_kg != null ? ` – ${numFmt(c.weight_kg)} kg` : "";
    return `${c.species}${w} · ${anglerOf(c)} · ${c.water} · ${dtFmt(c.caught_at)}`;
  }

  // Napló nézet: "detail" (részletes kártyák) vagy "compact" (egy sor egy fogás)
  function logView() {
    if (!state.logView) {
      try { state.logView = localStorage.getItem("logView") || "detail"; } catch (_) { state.logView = "detail"; }
    }
    return state.logView;
  }
  function setLogView(v) {
    state.logView = v;
    try { localStorage.setItem("logView", v); } catch (_) { /* nincs tároló */ }
    renderLog();
  }

  // Egy fogás részletes kártyája
  function cardHtml(c, opts) {
    const size = [c.weight_kg != null ? `${numFmt(c.weight_kg)} kg` : "", c.length_cm != null ? `${numFmt(c.length_cm, 1)} cm` : ""]
      .filter(Boolean).join(", ");
    const tags = [
      opts && opts.isNew ? `<span class="new-chip">ÚJ</span>` : "",
      c._pending ? `<span class="tag pending">Feltöltésre vár</span>` : "",
      isPB(c) ? `<span class="tag pb" title="A horgász eddigi legnagyobb hala ebből a fajból">🏅 Egyéni csúcs</span>` : "",
      c.released ? `<span class="tag">Visszaengedve</span>` : "",
      c.updated_at ? `<span class="tag" title="${esc(dtFmt(c.updated_at))}">Módosítva</span>` : "",
      c.guest_name ? `<span class="tag guest">Vendég – versenyen kívül</span>` : ""
    ].join("");
    const meta = [anglerOf(c), dtFmt(c.caught_at)].join(" · ");
    const inTrips = trips && !c._pending ? trips.tripsOfCatch(c) : [];
    const where = [c.water, c.spot].filter(Boolean).join(" – ");
    const how = [c.bait, c.method].filter(Boolean).join(" · ");
    const own = c.user_id === state.uid;
    const canEdit = own || (!c._pending && state.me && state.me.is_admin);
    const map = c.lat != null ? `<a href="https://www.google.com/maps?q=${c.lat},${c.lon}" target="_blank" rel="noopener">Térkép</a>` : "";
    const nPh = photoCount(c);
    const mo = moonInfo(new Date(c.caught_at));
    const inner = opts && opts.inner;
    return `
      <div class="${inner ? "catch catch-inner" : "card catch"}" data-id="${esc(c.client_id)}"${inner ? "" : ` id="fogas-${esc(c.client_id)}"`}>
        <div class="catch-photo-wrap">
          <div class="catch-photo" data-photo="${nPh ? "1" : ""}">${nPh ? "" : "🐟"}</div>
          ${nPh > 1 ? `<span class="photo-count">📷 ${nPh}</span>` : ""}
        </div>
        <div>
          <div class="catch-title">${esc(c.species)}${size ? " – " + esc(size) : ""}</div>
          <div class="catch-meta">${esc(meta)}</div>
          <div class="catch-meta">${esc(where)}</div>
          ${how ? `<div class="catch-meta">${esc(how)}</div>` : ""}
          ${c.note ? `<div class="catch-meta"><em>${esc(c.note)}</em></div>` : ""}
          ${c.weather ? `<div class="catch-wx">🌤 ${esc(weatherLine(c.weather))}</div>` : ""}
          <div class="catch-wx">${mo.icon} ${esc(mo.name)} · megvilágítottság kb. ${mo.illum_pct}%</div>
          <div class="catch-wx">🎉 Névnap: ${esc(nameDayText(new Date(c.caught_at)))}</div>
          ${inTrips.length ? `<div class="catch-wx">⚑ Túra: ${inTrips.map((t) => `<button type="button" class="link inline" data-trip-open="${esc(t.id)}">${esc(t.title)}</button>`).join(", ")}</div>` : ""}
          <div style="margin-top:4px">${tags}</div>
          <div class="catch-actions">
            ${map}
            <button type="button" class="link btn-share" data-id="${esc(c.client_id)}">Megosztás</button>
            ${canEdit ? `<button type="button" class="link btn-edit" data-id="${esc(c.client_id)}">Szerkesztés</button>` : ""}
            ${canEdit ? `<button type="button" class="link btn-del" data-id="${esc(c.client_id)}">Törlés</button>` : ""}
          </div>
        </div>
      </div>`;
  }

  // Egy fogás tömör sora (névnap itt nincs, csak a lenyíló részletekben)
  // ------------------------------------------------------------------
  // Egyéni csúcs (7.5): horgászonként és halfajonként a legnagyobb (tagoknál)
  // ------------------------------------------------------------------
  const spKey = (sp) => String(sp || "").trim().toLowerCase();
  let pbMemo = { src: null, n: -1, set: new Set() };
  function pbSet() {
    const all = everyEntry();
    if (pbMemo.src === state.catches && pbMemo.n === all.length) return pbMemo.set;
    const best = new Map();
    all.forEach((c) => {
      if (c.guest_name || c.weight_kg == null) return;
      const k = c.user_id + "|" + spKey(c.species), b = best.get(k), w = Number(c.weight_kg);
      if (!b || w > Number(b.weight_kg) || (w === Number(b.weight_kg) && c.caught_at < b.caught_at)) best.set(k, c);
    });
    pbMemo = { src: state.catches, n: all.length, set: new Set(Array.from(best.values()).map((c) => c.client_id)) };
    return pbMemo.set;
  }
  const isPB = (c) => !c.guest_name && pbSet().has(c.client_id);
  // Mentés előtt: új egyéni rekord vagy az első ilyen hal?
  function pbMessage(item) {
    if (item.guest_name || !item.species) return null;
    const mine = everyEntry().filter((c) => !c.guest_name && c.user_id === item.user_id && spKey(c.species) === spKey(item.species));
    if (!mine.length) return `🎉 Az első fogásod ebből a halfajból: ${item.species}!`;
    if (item.weight_kg == null) return null;
    const prev = mine.filter((c) => c.weight_kg != null).reduce((m, c) => Math.max(m, Number(c.weight_kg)), -1);
    if (prev >= 0 && Number(item.weight_kg) > prev) return `🏅 Új egyéni rekord! ${item.species}: ${numFmt(item.weight_kg)} kg (eddig: ${numFmt(prev)} kg)`;
    return null;
  }

  // Új fogás a naplóban: más rögzítette a napló utolsó megnyitása óta
  const isNewLog = (c, live) => !!(news && !c._pending && news.isNew(c.created_at, "log", c.user_id, live));

  function rowHtml(c) {
    const nPh = photoCount(c);
    const p = tzParts(new Date(c.caught_at));
    return `
      <div class="crow-wrap" id="fogas-${esc(c.client_id)}" data-id="${esc(c.client_id)}">
        <button type="button" class="crow" data-row="${esc(c.client_id)}" aria-expanded="false">
          <span class="crow-thumb">
            <span class="catch-photo" data-photo="${nPh ? "1" : ""}">${nPh ? "" : "🐟"}</span>
            ${nPh > 1 ? `<span class="crow-count">${nPh}</span>` : ""}
          </span>
          <span class="crow-main">
            <span class="crow-species">${isNewLog(c) ? `<span class="new-chip">ÚJ</span>` : ""}${esc(c.species)}${isPB(c) ? ` <span title="Egyéni csúcs">🏅</span>` : ""}${c.released ? ` <span class="crow-tag">vissza</span>` : ""}${c._pending ? ` <span class="crow-tag pending">vár</span>` : ""}</span>
            <span class="crow-sub">${esc(anglerOf(c))} · ${esc(c.water)}</span>
          </span>
          <span class="crow-right">
            <span class="crow-kg">${c.weight_kg != null ? esc(numFmt(c.weight_kg)) + " kg" : "–"}</span>
            <span class="crow-date">${p.y !== tzParts(new Date()).y ? p.y + "." : ""}${p.m}.${p.d}. ${p.h}:${p.min}</span>
          </span>
        </button>
        <div class="crow-detail hidden"></div>
      </div>`;
  }

  // Listaképek betöltése egy adott tárolóban (egy kötegben)
  function loadThumbs(container, list) {
    (async () => {
      const urls = await signedUrlsFor(list.filter((c) => !c._pending).map(coverPath));
      list.forEach((c) => {
        container.querySelectorAll(`[data-id="${CSS.escape(c.client_id)}"] .catch-photo[data-photo="1"]`).forEach((box) => {
          if (box.tagName === "IMG") return;
          let url = null;
          if (c._pending) { const b = coverBlob(c); if (b) url = URL.createObjectURL(b); }
          else url = urls[coverPath(c)];
          if (!url) { box.textContent = "📷"; return; }
          const img = document.createElement("img");
          img.className = "catch-photo";
          img.dataset.photo = "1";
          img.alt = c.species;
          img.loading = "lazy";
          img.src = url;
          if (!box.closest(".crow")) img.addEventListener("click", async () => openViewer(await photoUrlsOf(c), 0, captionOf(c)));
          box.replaceWith(img);
        });
      });
    })();
  }

  function toggleRow(id) {
    const wrap = document.querySelector(`.crow-wrap[data-id="${CSS.escape(id)}"]`);
    if (!wrap) return;
    const det = wrap.querySelector(".crow-detail");
    const btn = wrap.querySelector(".crow");
    const open = det.classList.contains("hidden");
    if (open) {
      const c = everyEntry().find((x) => x.client_id === id);
      if (!c) return;
      det.innerHTML = cardHtml(c, { inner: true });
      loadThumbs(det, [c]);
    }
    det.classList.toggle("hidden", !open);
    btn.setAttribute("aria-expanded", open ? "true" : "false");
    wrap.classList.toggle("open", open);
  }

  function renderLog() {
    const entries = allEntries();
    const uniqSorted = (arr) => Array.from(new Set(arr.filter(Boolean))).sort((a, b) => a.localeCompare(b, "hu"));
    fillSelect($("#fYear"), yearOptions(entries), "Minden év");
    fillSelect($("#fUser"),
      Array.from(new Set(entries.map((c) => c.user_id))).map((id) => ({ value: id, label: nameOf(id) }))
        .sort((a, b) => a.label.localeCompare(b.label, "hu")), "Minden horgász");
    fillSelect($("#fWater"), uniqSorted(entries.map((c) => c.water)).map((v) => ({ value: v, label: v })), "Minden vízterület");
    fillSelect($("#fSpecies"), uniqSorted(entries.map((c) => c.species)).map((v) => ({ value: v, label: v })), "Minden halfaj");

    const view = logView();
    $$("#logViewSeg [data-view]").forEach((b) => {
      const on = b.dataset.view === view;
      b.classList.toggle("active", on);
      b.setAttribute("aria-pressed", on ? "true" : "false");
    });

    // Rekordlisták nézet: saját szűrőkkel
    const rec = view === "records" && !!records;
    $("#stdFilters").classList.toggle("hidden", rec);
    $("#btnExport").classList.toggle("hidden", rec);
    $("#logList").classList.toggle("hidden", rec);
    $("#recOut").classList.toggle("hidden", !rec);
    if (rec) { records.render(); return; }
    if (news) news.enter("log");

    const list = filteredEntries();
    $("#logCount").textContent = `${list.length} fogás`;
    const out = $("#logList");
    if (!list.length) { out.innerHTML = `<div class="card empty">Nincs megjeleníthető fogás.</div>`; return; }

    // A nyitott tömör sorok újrarajzolás után is nyitva maradnak
    const openIds = $$(".crow-wrap.open").map((el) => el.dataset.id);
    if (view === "compact") {
      out.innerHTML = `<div class="card crow-list">${list.map(rowHtml).join("")}</div>`;
      const hl = state.highlight && Date.now() < state.highlight.until ? state.highlight.id : null;
      openIds.concat(hl ? [hl] : []).forEach((id) => {
        const w = document.querySelector(`.crow-wrap[data-id="${CSS.escape(id)}"]`);
        if (w && !w.classList.contains("open")) toggleRow(id);
      });
    } else {
      out.innerHTML = list.map((c) => cardHtml(c, { isNew: isNewLog(c) })).join("");
    }
    applyHighlight();
    loadThumbs(out, list);
  }

  // ------------------------------------------------------------------
  // Galéria: fotó + halfaj, horgász, súly, vízterület
  // ------------------------------------------------------------------
  function renderGallery() {
    if (news) news.enter("gallery");
    const withPhoto = allEntries().filter((c) => photoCount(c) > 0);
    const uniqSorted = (arr) => Array.from(new Set(arr.filter(Boolean))).sort((a, b) => a.localeCompare(b, "hu"));
    fillSelect($("#gYear"), yearOptions(withPhoto), "Év");
    fillSelect($("#gUser"), Array.from(new Set(withPhoto.map((c) => c.user_id))).map((id) => ({ value: id, label: nameOf(id) }))
      .sort((a, b) => a.label.localeCompare(b.label, "hu")), "Horgász");
    fillSelect($("#gSpecies"), uniqSorted(withPhoto.map((c) => c.species)).map((v) => ({ value: v, label: v })), "Halfaj");
    const y = $("#gYear").value, u = $("#gUser").value, sp = $("#gSpecies").value;
    const list = withPhoto.filter((c) => (!y || yearOf(c.caught_at) === y) && (!u || c.user_id === u) && (!sp || c.species === sp));
    const grid = $("#galleryGrid");
    if (!list.length) {
      grid.innerHTML = `<div class="card empty" style="grid-column:1/-1">Még nincs fotós fogás${y || u || sp ? " ezekkel a szűrőkkel" : ""}.</div>`;
      return;
    }
    grid.innerHTML = list.map((c) => `
      <button type="button" class="g-tile" data-id="${esc(c.client_id)}" aria-label="${esc(captionOf(c))}">
        <img alt="" loading="lazy">
        ${photoCount(c) > 1 ? `<span class="photo-count" style="top:6px;bottom:auto">📷 ${photoCount(c)}</span>` : ""}
        ${news && news.isNew(c.created_at, "gallery", c.user_id) ? `<span class="a-new left">ÚJ</span>` : ""}
        <div class="g-info">
          <div class="g-species">${esc(c.species)}</div>
          ${c.weight_kg != null ? `<div class="g-weight">${esc(numFmt(c.weight_kg))} kg</div>` : ""}
          <div class="g-meta">${esc(nameOf(c.user_id))}</div>
          <div class="g-meta">${esc(c.water)}</div>
        </div>
      </button>`).join("");
    (async () => {
      const urls = await signedUrlsFor(list.filter((c) => !c._pending).map(coverPath));
      list.forEach((c) => {
        const img = grid.querySelector(`.g-tile[data-id="${CSS.escape(c.client_id)}"] img`);
        if (!img) return;
        if (c._pending) { const b = coverBlob(c); if (b) img.src = URL.createObjectURL(b); }
        else if (urls[coverPath(c)]) img.src = urls[coverPath(c)];
      });
    })();
  }

  async function openGalleryTile(id) {
    const c = allEntries().find((x) => x.client_id === id);
    if (c) openViewer(await photoUrlsOf(c), 0, captionOf(c));
  }

  // ------------------------------------------------------------------
  // Megosztás (Viber, WhatsApp stb. a telefon megosztás menüjén át)
  // ------------------------------------------------------------------
  const APP_URL = (() => { try { return new URL("./", location.href).href; } catch (_) { return location.href; } })();
  const share = { file: null, text: "" };

  function shareTextOf(c) {
    const size = [c.weight_kg != null ? `${numFmt(c.weight_kg)} kg` : "", c.length_cm != null ? `${numFmt(c.length_cm, 1)} cm` : ""].filter(Boolean).join(", ");
    const mo = moonInfo(new Date(c.caught_at));
    const lines = [
      `🎣 ${anglerOf(c)}: ${c.species}${size ? " – " + size : ""}`,
      `📍 ${[c.water, c.spot].filter(Boolean).join(" – ")}`,
      `🕒 ${dtFmt(c.caught_at)}`
    ];
    if (c.bait || c.method) lines.push(`🪱 ${[c.bait, c.method].filter(Boolean).join(" · ")}`);
    if (c.weather) lines.push(`🌤 ${weatherLine(c.weather)}`);
    lines.push(`${mo.icon} ${mo.name}`);
    if (c.released) lines.push("↩️ Visszaengedve");
    if (c.guest_name) lines.push(`👤 Vendégfogás (versenyen kívül), rögzítette: ${nameOf(c.user_id)}`);
    if (c.note) lines.push(`💬 ${c.note}`);
    lines.push("", `${CFG.CLUB_NAME || "Horgásznapló"}: ${APP_URL}`);
    return lines.join("\n");
  }

  async function openShare(c, afterSave) {
    share.file = null;
    share.text = shareTextOf(c);
    $("#shareTitle").textContent = afterSave ? "Elküldöd a csoportnak is?" : "Fogás megosztása";
    $("#shareText").textContent = share.text;
    $("#shareMsg").textContent = "";
    const img = $("#shareImg");
    img.classList.add("hidden");
    $("#btnShareGo").disabled = false;
    $("#shareSheet").classList.remove("hidden");
    // A listakép előkészítése, hogy a megosztás gomb azonnal tudjon küldeni
    try {
      let blob = null;
      if (c._pending) blob = coverBlob(c);
      else if (coverPath(c)) {
        $("#btnShareGo").disabled = true;
        $("#shareMsg").textContent = "Fotó előkészítése…";
        const url = await signedUrl(coverPath(c));
        if (url) blob = await (await fetch(url)).blob();
        $("#shareMsg").textContent = "";
      }
      if (blob) {
        share.file = new File([blob], `fogas-${(c.species || "hal").toLowerCase()}.jpg`, { type: blob.type || "image/jpeg" });
        img.src = URL.createObjectURL(blob);
        img.classList.remove("hidden");
      }
    } catch (e) {
      $("#shareMsg").textContent = "A fotót nem sikerült előkészíteni, csak a szöveg kerül megosztásra.";
    } finally {
      $("#btnShareGo").disabled = false;
    }
  }

  async function doShare() {
    const msg = $("#shareMsg");
    try {
      if (navigator.share) {
        const withFile = share.file && navigator.canShare && navigator.canShare({ files: [share.file] });
        await navigator.share(withFile ? { files: [share.file], text: share.text } : { text: share.text });
        closeShare();
        return;
      }
      await navigator.clipboard.writeText(share.text);
      msg.className = "msg ok";
      msg.textContent = "Ezen a készüléken nincs megosztás menü: a szöveget kimásoltam, beillesztheted a csoportba.";
    } catch (e) {
      if (e && e.name === "AbortError") return; // a felhasználó bezárta a menüt
      msg.className = "msg err";
      msg.textContent = "A megosztás nem sikerült: " + errText(e);
    }
  }
  function closeShare() { $("#shareSheet").classList.add("hidden"); }

  // ------------------------------------------------------------------
  // Push-értesítések
  // ------------------------------------------------------------------
  const PUSH_OK = "serviceWorker" in navigator && "PushManager" in window && "Notification" in window;

  function b64uToU8(b64u) {
    const s = b64u.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((b64u.length + 3) % 4);
    const bin = atob(s);
    return Uint8Array.from(bin, (ch) => ch.charCodeAt(0));
  }

  async function callFn(body) {
    const { data, error } = await state.sb.functions.invoke("ertesites", { body });
    if (error) {
      let detail = "";
      try { const j = await error.context.json(); detail = j && j.error; } catch (_) { /* nincs részlet */ }
      const status = error.context && error.context.status;
      if (status === 404) throw new Error("Az értesítési szolgáltatás még nincs telepítve a Supabase-ben (útmutató 12. fejezet).");
      throw new Error(detail || error.message || "Az értesítési szolgáltatás nem érhető el.");
    }
    return data;
  }

  async function swReady() {
    return Promise.race([
      navigator.serviceWorker.ready,
      new Promise((_, rej) => setTimeout(() => rej(new Error("Az app háttérszolgáltatása nem indult el. Frissítsd az oldalt.")), 8000))
    ]);
  }

  async function currentPushSub() {
    if (!PUSH_OK) return null;
    const reg = await navigator.serviceWorker.getRegistration();
    return reg ? reg.pushManager.getSubscription() : null;
  }

  async function updatePushMenu() {
    const sub = await currentPushSub().catch(() => null);
    $("#menuPush").textContent = sub ? "🔕 Értesítések kikapcsolása" : "🔔 Értesítések bekapcsolása";
    $("#menuPushTest").classList.toggle("hidden", !sub);
    $("#menuPush").classList.toggle("hidden", (!PUSH_OK && !IS_IOS) || isViewer());
    if (isViewer()) $("#menuPushTest").classList.add("hidden");
    return !!sub;
  }

  async function updatePushHint() {
    let dismissed = false;
    try { dismissed = localStorage.getItem("pushHintHidden") === "1"; } catch (_) { /* nincs tároló */ }
    const on = await updatePushMenu();
    $("#pushHint").classList.toggle("hidden", isViewer() || on || dismissed || (!PUSH_OK && !IS_IOS) || (typeof Notification !== "undefined" && Notification.permission === "denied"));
  }

  async function enablePush() {
    try {
      if (IS_IOS && !IS_STANDALONE) throw new Error("iPhone-on az értesítéshez előbb tedd ki az appot a kezdőképernyőre (Megosztás → Főképernyőhöz adás), és onnan indítsd.");
      if (!PUSH_OK) throw new Error("Ez a böngésző nem támogatja az értesítéseket.");
      if (!navigator.onLine) throw new Error("A bekapcsoláshoz internetkapcsolat kell.");
      const perm = await Notification.requestPermission();
      if (perm !== "granted") throw new Error("Az értesítések nincsenek engedélyezve. A telefon beállításaiban engedélyezheted ennek az appnak.");
      const { publicKey } = await callFn({ action: "key" });
      const reg = await swReady();
      let sub = await reg.pushManager.getSubscription();
      if (!sub) sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64uToU8(publicKey) });
      await callFn({ action: "subscribe", subscription: sub.toJSON() });
      toast("Értesítések bekapcsolva ezen a készüléken.");
    } catch (e) {
      toast(errText(e), 6000);
    }
    updatePushHint();
  }

  async function disablePush() {
    try {
      const sub = await currentPushSub();
      if (sub) {
        await callFn({ action: "unsubscribe", endpoint: sub.endpoint }).catch(() => {});
        await sub.unsubscribe();
      }
      toast("Értesítések kikapcsolva ezen a készüléken.");
    } catch (e) { toast(errText(e)); }
    updatePushHint();
  }

  async function testPush() {
    try {
      const r = await callFn({ action: "test", url: APP_URL });
      toast(r && r.ok ? "Próba-értesítés elküldve. Pár másodpercen belül meg kell érkeznie." : "A próba-értesítés nem ment ki.", 5000);
    } catch (e) { toast(errText(e), 6000); }
  }

  // Új fogásról értesítés a többieknek (a szerver csak egyszer küldi ki)
  function notifyNewCatch(clientId) {
    if (!state.sb) return;
    callFn({ action: "new_catch", client_id: clientId, url: APP_URL }).catch((e) => console.warn("Értesítés:", e));
  }

  // Értesítésre koppintva: a fogás megnyitása a naplóban
  function openCatchFromHash() {
    if (trips && trips.openFromHash()) return;
    const m = location.hash.match(/^#fogas-([0-9a-f-]{8,})$/i);
    if (!m) return;
    history.replaceState(history.state, "", location.pathname + location.search);
    state.highlight = { id: m[1], until: Date.now() + 5000, scrolled: false };
    showTab("tabLog");
    setTimeout(() => { state.highlight = null; $$(".catch.highlight").forEach((el) => el.classList.remove("highlight")); }, 5000);
  }

  // A naplóban kiemelt fogás (értesítésből megnyitva) – újrarajzolás után is megmarad
  function applyHighlight() {
    const h = state.highlight;
    if (!h || Date.now() > h.until) return;
    const el = document.getElementById("fogas-" + h.id);
    if (!el) return;
    el.classList.add("highlight");
    if (!h.scrolled) { h.scrolled = true; setTimeout(() => el.scrollIntoView({ behavior: "smooth", block: "center" }), 100); }
  }

  async function deleteEntry(clientId) {
    const pending = state.outbox.find((x) => x.client_id === clientId);
    if (!confirm("Biztosan törlöd ezt a fogást? A törlés nem vonható vissza.")) return;
    try {
      if (pending) {
        await idb.del("outbox", clientId);
        state.outbox = state.outbox.filter((x) => x.client_id !== clientId);
      } else {
        if (!navigator.onLine) { toast("Törléshez internetkapcsolat szükséges."); return; }
        const c = state.catches.find((x) => x.client_id === clientId);
        const { data: del, error } = await state.sb.from("catches").delete().eq("client_id", clientId).select("client_id");
        if (error) throw error;
        if (!del || !del.length) throw new Error("Nincs jogosultságod ennek a fogásnak a törléséhez.");
        if (c) { const ps = catchPhotoPaths(c); if (ps.length) await state.sb.storage.from("photos").remove(ps).catch(() => {}); }
        state.catches = state.catches.filter((x) => x.client_id !== clientId);
        await idb.put("kv", state.catches, "catches");
      }
      updateNet();
      renderLog();
      if (trips && !$("#tabTrips").classList.contains("hidden")) trips.render();
      toast("Törölve.");
    } catch (e) {
      toast("A törlés nem sikerült: " + errText(e));
    }
  }

  // Excel-kompatibilis CSV (pontosvessző, tizedesvessző, UTF-8 BOM)
  function exportCsv() {
    const list = filteredEntries();
    if (!list.length) { toast("Nincs exportálható adat."); return; }
    const n = (v, d = 2) => (v == null ? "" : numFmt(v, d).replace(/\s/g, ""));
    const head = ["Időpont", "Horgász", "Halfaj", "Súly (kg)", "Hossz (cm)", "Vízterület", "Helyszín", "Csali",
      "Módszer", "Visszaengedve", "Megjegyzés", "Szélesség", "Hosszúság", "Hőmérséklet (°C)", "Légnyomás (hPa)",
      "Nyomásváltozás 3 óra (hPa)", "Szél (km/h)", "Szélirány", "Felhőzet (%)", "Csapadék (mm)", "Időjárás", "Holdfázis", "Hold megvilágítottság (%)", "Névnap", "Fotók száma", "Állapot"];
    const rows = list.map((c) => {
      const w = c.weather || {};
      const mo = moonInfo(new Date(c.caught_at));
      return [dtFmt(c.caught_at), nameOf(c.user_id), c.species, n(c.weight_kg), n(c.length_cm, 1), c.water, c.spot,
        c.bait, c.method, c.released ? "igen" : "nem", c.note,
        c.lat != null ? String(c.lat).replace(".", ",") : "", c.lon != null ? String(c.lon).replace(".", ",") : "",
        n(w.temp_c, 1), n(w.pressure_hpa, 1), n(w.pressure_trend_3h, 1), n(w.wind_kmh, 1), windDir(w.wind_dir_deg),
        n(w.cloud_pct, 0), n(w.precip_mm, 1), w.desc || "", mo.name, mo.illum_pct, nameDayText(new Date(c.caught_at)), photoCount(c), c._pending ? "feltöltésre vár" : "feltöltve"];
    });
    const cell = (v) => {
      const s = String(v ?? "");
      return /[";\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    };
    const csv = "﻿" + [head].concat(rows).map((r) => r.map(cell).join(";")).join("\r\n");
    const p = tzParts(new Date());
    const fname = `horgasznaplo_${p.y}${p.m}${p.d}_${p.h}${p.min}.csv`;
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });

    // iPhone: a megosztás menün keresztül (Fájlok, Mail stb.), mert a telepített appból a letöltés nem megbízható
    if (IS_IOS && navigator.canShare) {
      const file = new File([blob], fname, { type: "text/csv" });
      if (navigator.canShare({ files: [file] })) {
        navigator.share({ files: [file], title: fname })
          .then(() => toast("Exportálva."))
          .catch((e) => { if (e && e.name !== "AbortError") toast("A megosztás nem sikerült: " + errText(e)); });
        return;
      }
    }

    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = fname;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
    toast(`Letöltve: ${fname}`);
  }

  // ------------------------------------------------------------------
  // Összesítők
  // ------------------------------------------------------------------
  // ------------------------------------------------------------------
  // Évértékelő (7.5): az év számai egy oldalon
  // ------------------------------------------------------------------
  const HU_MONTH = ["január", "február", "március", "április", "május", "június", "július", "augusztus", "szeptember", "október", "november", "december"];
  function yearReviewHtml(list, y) {
    if (!list.length) return `<div class="card empty">Nincs adat.</div>`;
    const wt = (c) => (c.weight_kg == null ? null : Number(c.weight_kg));
    const kgs = (arr) => arr.reduce((s, c) => s + (wt(c) || 0), 0);
    const by = (keyFn) => { const m = new Map(); list.forEach((c) => { const k = keyFn(c); if (k == null) return; if (!m.has(k)) m.set(k, []); m.get(k).push(c); }); return m; };
    const top = (m, score) => Array.from(m.entries()).sort((a, b) => score(b[1]) - score(a[1]));
    const medal = (i) => ["🥇", "🥈", "🥉"][i] || `${i + 1}.`;
    const kgTxt = (v) => `${numFmt(Math.round(v * 10) / 10)} kg`;
    const users = by((c) => c.user_id), species = by((c) => c.species), waters = by((c) => c.water);
    const withW = list.filter((c) => wt(c) != null);
    const biggestAll = withW.slice().sort((a, b) => wt(b) - wt(a))[0];
    const byCount = top(users, (a) => a.length).slice(0, 3);
    const byKg = top(users, kgs).filter(([, a]) => kgs(a) > 0).slice(0, 3);
    const spBest = top(species, (a) => a.length).map(([sp, arr]) => [sp, arr.filter((c) => wt(c) != null).sort((a, b) => wt(b) - wt(a))[0], arr.length]);
    const bestOf = (m, label) => { const t = top(m, (a) => a.length)[0]; return t ? { key: label(t[0]), n: t[1].length } : null; };
    const month = bestOf(by((c) => Number(tzParts(new Date(c.caught_at)).m) - 1), (k) => HU_MONTH[k]);
    const hourPart = (c) => { const h = Number(tzParts(new Date(c.caught_at)).h); return h >= 4 && h < 7 ? "hajnal" : h < 12 && h >= 7 ? "délelőtt" : h >= 12 && h < 17 ? "délután" : h >= 17 && h < 21 ? "este" : "éjszaka"; };
    const part = bestOf(by(hourPart), (k) => k);
    const moon = bestOf(by((c) => moonInfo(new Date(c.caught_at)).idx), (k) => MOON_NAMES[k].toLowerCase());
    const water = bestOf(waters, (k) => k);
    // Legjobb túra: a tagok fogásainak száma szerint
    let bestTrip = null;
    if (trips) {
      const tm = new Map();
      list.forEach((c) => trips.tripsOfCatch(c).forEach((t) => { if (!tm.has(t.id)) tm.set(t.id, { t, arr: [] }); tm.get(t.id).arr.push(c); }));
      bestTrip = Array.from(tm.values()).sort((a, b) => b.arr.length - a.arr.length || kgs(b.arr) - kgs(a.arr))[0] || null;
    }
    const row = (l, v) => `<div class="yr-row"><span>${l}</span><b>${v}</b></div>`;
    return `
      <div class="card yr-head"><div class="yr-title">🏆 Évértékelő ${y ? esc(y) : "– minden év"}</div>
        <div class="yr-big">${list.length} fogás · ${esc(kgTxt(kgs(list)))}</div>
        <div class="hint">${species.size} halfaj · ${users.size} horgász · ${waters.size} vízterület${bestTrip ? "" : ""}</div></div>
      ${biggestAll ? `<div class="card"><h3>🐟 Az év hala</h3>
        <div class="yr-fish">${esc(biggestAll.species)} – ${esc(kgTxt(wt(biggestAll)))}</div>
        <div class="hint">${esc(nameOf(biggestAll.user_id))} · ${esc(biggestAll.water)} · ${esc(dtFmt(biggestAll.caught_at))}</div></div>` : ""}
      <div class="card"><h3>🎣 Az év horgásza</h3>
        <div class="yr-sub">Legtöbb fogás</div>${byCount.map(([u, a], i) => row(`${medal(i)} ${esc(nameOf(u))}`, `${a.length} db`)).join("")}
        ${byKg.length ? `<div class="yr-sub">Legnagyobb össztömeg</div>${byKg.map(([u, a], i) => row(`${medal(i)} ${esc(nameOf(u))}`, esc(kgTxt(kgs(a))))).join("")}` : ""}</div>
      <div class="card"><h3>📏 Fajonként a legnagyobb</h3>
        ${spBest.map(([sp, c, n]) => row(`${esc(sp)} <small class="hint">(${n} db)</small>`, c ? `${esc(kgTxt(wt(c)))} <small class="hint">${esc(nameOf(c.user_id))}</small>` : "–")).join("")}</div>
      <div class="card"><h3>📅 Mikor és hol fogott a legjobban?</h3>
        ${month ? row("Legjobb hónap", `${esc(month.key)} <small class="hint">(${month.n} db)</small>`) : ""}
        ${part ? row("Legjobb napszak", `${esc(part.key)} <small class="hint">(${part.n} db)</small>`) : ""}
        ${moon ? row("Legjobb holdfázis", `${esc(moon.key)} <small class="hint">(${moon.n} db)</small>`) : ""}
        ${water ? row("Kedvenc vízterület", `${esc(water.key)} <small class="hint">(${water.n} db)</small>`) : ""}
        ${bestTrip ? row("Legjobb túra", `${esc(bestTrip.t.title)} <small class="hint">(${bestTrip.arr.length} db, ${esc(kgTxt(kgs(bestTrip.arr)))})</small>`) : ""}</div>
      <p class="hint stats-note">A vendégfogások nem számítanak bele. A „legjobb” a fogások száma szerint értendő.</p>`;
  }

  function renderStats() {
    const entries = allEntries();
    fillSelect($("#sYear"), yearOptions(entries), "Minden év");
    const y = $("#sYear").value;
    const mode = $("#sMode").value;
    const list = entries.filter((c) => !y || yearOf(c.caught_at) === y);
    // Holdfázis: halfaj szerint is szűrhető (7.5)
    const spSel = $("#sSpecies");
    const spMode = ["moon", "pressure", "daypart", "temp", "wind"].includes(mode);
    spSel.classList.toggle("hidden", !spMode);
    if (spMode) fillSelect(spSel, Array.from(new Set(list.map((c) => c.species).filter(Boolean))).sort((a, b) => a.localeCompare(b, "hu")).map((v) => ({ value: v, label: v })), "Minden halfaj");
    const sp = spMode ? spSel.value : "";
    const out = $("#statsOut");
    if (!list.length) { out.innerHTML = `<div class="card empty">Nincs adat.</div>`; return; }

    const w = (c) => (c.weight_kg == null ? 0 : Number(c.weight_kg));
    const group = (keyFn) => {
      const m = new Map();
      list.forEach((c) => {
        const k = keyFn(c);
        if (!m.has(k)) m.set(k, []);
        m.get(k).push(c);
      });
      return m;
    };
    const biggest = (arr) => arr.reduce((best, c) => (c.weight_kg != null && (!best || w(c) > w(best)) ? c : best), null);
    const table = (heads, rows) => `
      <div class="card table-wrap"><table class="stats-table">
        <thead><tr>${heads.map((h) => `<th class="${h.num ? "num" : ""}">${esc(h.t)}</th>`).join("")}</tr></thead>
        <tbody>${rows.map((r) => `<tr>${r.map((v, i) => `<td class="${heads[i].num ? "num" : ""}">${v}</td>`).join("")}</tr>`).join("")}</tbody>
      </table></div>`;

    // Sávos táblázat (holdfázis mintájára): db, össztömeg, legnagyobb hal
    const sel = list.filter((c) => !sp || c.species === sp);
    const spNote = sp ? `<p class="hint stats-note">Csak: <b>${esc(sp)}</b></p>` : "";
    const bucketTable = (title, buckets, valOf) => {
      const rows = buckets.map((bk) => {
        const arr = sel.filter((c) => { const v = valOf(c); return v != null && !Number.isNaN(v) && bk.test(v); });
        const b = biggest(arr);
        return [`${esc(bk.label)}${bk.sub ? `<br><small class="hint">${esc(bk.sub)}</small>` : ""}`, arr.length, numFmt(arr.reduce((s2, c) => s2 + w(c), 0)),
          b ? `${numFmt(b.weight_kg)} kg<br><small>${esc(b.species)}</small>` : "–"];
      });
      return table([{ t: title }, { t: "Db", num: true }, { t: "Össz. kg", num: true }, { t: "Legnagyobb", num: true }], rows);
    };
    const wx = (c, k) => (c.weather && c.weather[k] != null ? Number(c.weather[k]) : null);
    const missing = (k, what) => { const n = sel.filter((c) => wx(c, k) == null).length; return n ? ` ${n} fogásnál nincs ${what}.` : ""; };

    if (mode === "daypart") {
      const hour = (c) => Number(tzParts(new Date(c.caught_at)).h);
      out.innerHTML = spNote + bucketTable("Napszak", [
        { label: "🌅 Hajnal", sub: "4:00–6:59", test: (h) => h >= 4 && h < 7 },
        { label: "☀️ Délelőtt", sub: "7:00–11:59", test: (h) => h >= 7 && h < 12 },
        { label: "🌤 Délután", sub: "12:00–16:59", test: (h) => h >= 12 && h < 17 },
        { label: "🌇 Este", sub: "17:00–20:59", test: (h) => h >= 17 && h < 21 },
        { label: "🌙 Éjszaka", sub: "21:00–3:59", test: (h) => h >= 21 || h < 4 }
      ], hour) + `<p class="hint stats-note">A fogás időpontja szerint (budapesti idő).</p>`;
      return;
    }
    if (mode === "temp") {
      out.innerHTML = spNote + bucketTable("Léghőmérséklet", [
        { label: "Fagyos, hideg", sub: "5 °C alatt", test: (v) => v < 5 },
        { label: "Hűvös", sub: "5–9,9 °C", test: (v) => v >= 5 && v < 10 },
        { label: "Enyhe", sub: "10–14,9 °C", test: (v) => v >= 10 && v < 15 },
        { label: "Kellemes", sub: "15–19,9 °C", test: (v) => v >= 15 && v < 20 },
        { label: "Meleg", sub: "20–24,9 °C", test: (v) => v >= 20 && v < 25 },
        { label: "Forró", sub: "25 °C és felette", test: (v) => v >= 25 }
      ], (c) => wx(c, "temp_c")) + `<p class="hint stats-note">A fogás időpontjában, 2 m magasan mért léghőmérséklet (Open-Meteo), nem a víz hőmérséklete.${missing("temp_c", "hőmérsékletadat")}</p>`;
      return;
    }
    if (mode === "wind") {
      out.innerHTML = spNote + bucketTable("Szélerősség", [
        { label: "Szélcsend", sub: "5 km/h alatt", test: (v) => v < 5 },
        { label: "Gyenge szél", sub: "5–11,9 km/h", test: (v) => v >= 5 && v < 12 },
        { label: "Mérsékelt szél", sub: "12–19,9 km/h", test: (v) => v >= 12 && v < 20 },
        { label: "Élénk szél", sub: "20–29,9 km/h", test: (v) => v >= 20 && v < 30 },
        { label: "Erős szél", sub: "30 km/h és felette", test: (v) => v >= 30 }
      ], (c) => wx(c, "wind_kmh")) + `<p class="hint stats-note">A fogás időpontjában, 10 m magasan mért átlagos szélsebesség (Open-Meteo).${missing("wind_kmh", "széladat")}</p>`;
      return;
    }
    if (mode === "year") { out.innerHTML = yearReviewHtml(list, y); return; }

    if (mode === "cross") {
      out.innerHTML = tally ? `<div class="card"><p class="hint">Horgászonként és halfajonként: darab / össztömeg${y ? ` (${esc(y)})` : ""}. A vendégfogás itt nem számít.</p>${tally.summaryHtml(list)}</div>` : "";
      return;
    }
    if (mode === "user" || mode === "water" || mode === "species") {
      const keyFn = mode === "user" ? (c) => c.user_id : mode === "water" ? (c) => c.water : (c) => c.species;
      const label = mode === "user" ? nameOf : (k) => k;
      const rows = Array.from(group(keyFn).entries()).map(([k, arr]) => {
        const sum = arr.reduce((s, c) => s + w(c), 0);
        const b = biggest(arr);
        return { k: label(k), n: arr.length, sum, b, rel: arr.filter((c) => c.released).length };
      }).sort((a, b) => b.sum - a.sum || b.n - a.n);
      const first = mode === "user" ? "Horgász" : mode === "water" ? "Vízterület" : "Halfaj";
      const bigCell = (b) => (b ? `${numFmt(b.weight_kg)} kg<br><small>${esc(mode === "species" ? nameOf(b.user_id) : b.species)}</small>` : "–");
      out.innerHTML = table(
        [{ t: first }, { t: "Db", num: true }, { t: "Össz. kg", num: true }, { t: "Legnagyobb", num: true }, { t: "Vissza", num: true }],
        rows.map((r) => [esc(r.k), r.n, numFmt(r.sum), bigCell(r.b), r.rel])
      );
    } else if (mode === "records") {
      const rows = Array.from(group((c) => c.species).entries())
        .map(([sp, arr]) => ({ sp, b: biggest(arr) }))
        .filter((r) => r.b)
        .sort((a, b) => w(b.b) - w(a.b));
      out.innerHTML = rows.length ? table(
        [{ t: "Halfaj" }, { t: "Súly", num: true }, { t: "Horgász" }, { t: "Hely, idő" }],
        rows.map((r) => [esc(r.sp), `${numFmt(r.b.weight_kg)} kg${r.b.length_cm != null ? `<br><small>${numFmt(r.b.length_cm, 1)} cm</small>` : ""}`,
          esc(nameOf(r.b.user_id)), `${esc(r.b.water)}<br><small>${esc(dtFmt(r.b.caught_at))}</small>`])
      ) : `<div class="card empty">Nincs súllyal rögzített fogás.</div>`;
    } else if (mode === "moon") {
      const g = new Map();
      sel.forEach((c) => {
        const k = moonInfo(new Date(c.caught_at)).idx;
        if (!g.has(k)) g.set(k, []);
        g.get(k).push(c);
      });
      const rows = MOON_NAMES.map((nm, i) => {
        const arr = g.get(i) || [];
        const b = biggest(arr);
        return [esc(["🌑","🌒","🌓","🌔","🌕","🌖","🌗","🌘"][i] + " " + nm), arr.length, numFmt(arr.reduce((s, c) => s + w(c), 0)),
          b ? `${numFmt(b.weight_kg)} kg<br><small>${esc(b.species)}</small>` : "–"];
      });
      out.innerHTML = spNote +
        table([{ t: "Holdfázis" }, { t: "Db", num: true }, { t: "Össz. kg", num: true }, { t: "Legnagyobb", num: true }], rows);
    } else if (mode === "pressure") {
      // Légnyomás (7.5): tartomány és 3 órás változás szerint, a holdfázis mintájára
      const LEVEL = [
        { label: "Alacsony", sub: "< 1005 hPa", test: (v) => v < 1005 },
        { label: "Mérsékelten alacsony", sub: "1005–1012 hPa", test: (v) => v >= 1005 && v < 1013 },
        { label: "Átlagos", sub: "1013–1019 hPa", test: (v) => v >= 1013 && v < 1020 },
        { label: "Mérsékelten magas", sub: "1020–1026 hPa", test: (v) => v >= 1020 && v < 1027 },
        { label: "Magas", sub: "≥ 1027 hPa", test: (v) => v >= 1027 }
      ];
      const TREND = [
        { label: "↓↓ Gyorsan csökkenő", sub: "több mint 1,5 hPa-t esett", test: (v) => v < -1.5 },
        { label: "↓ Csökkenő", sub: "0,5–1,5 hPa-t esett", test: (v) => v >= -1.5 && v < -0.5 },
        { label: "→ Stagnáló", sub: "±0,5 hPa-n belül", test: (v) => v >= -0.5 && v <= 0.5 },
        { label: "↑ Emelkedő", sub: "0,5–1,5 hPa-t nőtt", test: (v) => v > 0.5 && v <= 1.5 },
        { label: "↑↑ Gyorsan emelkedő", sub: "több mint 1,5 hPa-t nőtt", test: (v) => v > 1.5 }
      ];
      out.innerHTML = spNote + bucketTable("Légnyomás", LEVEL, (c) => wx(c, "pressure_hpa")) +
        bucketTable("Változás (3 óra)", TREND, (c) => wx(c, "pressure_trend_3h")) +
        `<p class="hint stats-note">A fogás időpontjában, tengerszintre átszámított légnyomás és az azt megelőző 3 óra változása (Open-Meteo).${missing("pressure_hpa", "légnyomásadat")}</p>`;
    } else if (mode === "month") {
      const rows = Array.from(group((c) => monthOf(c.caught_at)).entries())
        .sort((a, b) => (a[0] < b[0] ? 1 : -1))
        .map(([m, arr]) => [esc(m), arr.length, numFmt(arr.reduce((s, c) => s + w(c), 0))]);
      out.innerHTML = table([{ t: "Hónap" }, { t: "Db", num: true }, { t: "Össz. kg", num: true }], rows);
    }
  }

  // ------------------------------------------------------------------
  // Tagok (admin)
  // ------------------------------------------------------------------
  async function showMembers() {
    show("viewMembers");
    const box = $("#memberList");
    box.innerHTML = `<p class="hint">Betöltés…</p>`;
    try {
      const { data, error } = await state.sb.from("profiles").select("*")
        .order("approved").order("created_at", { ascending: false });
      if (error) throw error;
      const members = data.filter((p) => p.role !== "viewer");
      const viewers = data.filter((p) => p.role === "viewer");
      box.innerHTML = members.map((p) => `
        <div class="member">
          <div>${esc(p.display_name)}${p.is_admin ? " (admin)" : ""}
            <small>${p.approved ? "Jóváhagyva" : "Jóváhagyásra vár"} · regisztrált: ${esc(dtFmt(p.created_at))}</small>
            ${cel ? cel.memberHtml(p) : ""}
          </div>
          ${p.id === state.uid ? "" : `<button type="button" class="btn small ${p.approved ? "danger" : "primary"}" data-member="${esc(p.id)}" data-ok="${p.approved ? "0" : "1"}">${p.approved ? "Letiltás" : "Jóváhagyás"}</button>`}
        </div>`).join("") + (viewers.length && family ? `<h3 class="members-sub">Nézelődők</h3>${family.viewerListHtml("members", viewers, "Nincs aktív hozzáférésű nézelődő.")}` : "")
        || `<p class="hint">Nincs tag.</p>`;
    } catch (e) {
      box.innerHTML = `<p class="msg err">${esc(errText(e))}</p>`;
    }
  }

  async function setApproval(id, ok) {
    try {
      const { error } = await state.sb.rpc("set_member_approval", { member: id, ok });
      if (error) throw error;
      toast(ok ? "Tag jóváhagyva." : "Tag letiltva.");
      showMembers();
    } catch (e) {
      toast(errText(e));
    }
  }

  async function rename() {
    $("#menuPanel").classList.add("hidden");
    const name = prompt("Új megjelenített név:", state.me.display_name || "");
    if (name == null) return;
    const v = name.trim().slice(0, 40);
    if (!v) return;
    try {
      const { error } = await state.sb.from("profiles").update({ display_name: v }).eq("id", state.uid);
      if (error) throw error;
      state.me.display_name = v;
      await idb.put("kv", state.me, "me");
      $("#menuUser").textContent = v + (state.me.is_admin ? " (admin)" : "");
      toast("Név módosítva.");
      refreshData();
    } catch (e) {
      toast(errText(e));
    }
  }

  // ------------------------------------------------------------------
  // Eseménykezelők
  // ------------------------------------------------------------------
  function bindUi() {
    $$(".seg-btn").forEach((b) => b.addEventListener("click", () => setAuthMode(b.dataset.auth)));
    $("#authForm").addEventListener("submit", onAuthSubmit);
    $("#catchForm").addEventListener("submit", onSave);
    $("#photoCamera").addEventListener("change", onPhotoPicked);
    $("#photoGallery").addEventListener("change", onPhotoPicked);
    $("#photoGrid").addEventListener("click", onPhotoGridClick);
    ["#gYear", "#gUser", "#gSpecies"].forEach((sel) => $(sel).addEventListener("change", renderGallery));
    $("#galleryGrid").addEventListener("click", (e) => { const t = e.target.closest(".g-tile"); if (t) openGalleryTile(t.dataset.id); });
    $("#viewerPrev").addEventListener("click", (e) => { e.stopPropagation(); stepViewer(-1); });
    $("#viewerNext").addEventListener("click", (e) => { e.stopPropagation(); stepViewer(1); });
    $("#viewerClose").addEventListener("click", (e) => { e.stopPropagation(); $("#photoModal").classList.add("hidden"); });
    let touchX = null;
    $("#photoModal").addEventListener("touchstart", (e) => { touchX = e.touches[0].clientX; }, { passive: true });
    $("#photoModal").addEventListener("touchend", (e) => {
      if (touchX == null) return;
      const dx = e.changedTouches[0].clientX - touchX; touchX = null;
      if (Math.abs(dx) > 50) stepViewer(dx < 0 ? 1 : -1);
    });
    $("#btnShareGo").addEventListener("click", doShare);
    $("#btnShareClose").addEventListener("click", closeShare);
    $("#shareSheet").addEventListener("click", (e) => { if (e.target.id === "shareSheet") closeShare(); });
    $("#btnPushHintOn").addEventListener("click", enablePush);
    $("#btnPushHintLater").addEventListener("click", () => {
      try { localStorage.setItem("pushHintHidden", "1"); } catch (_) { /* nincs tároló */ }
      $("#pushHint").classList.add("hidden");
    });
    $("#btnGps").addEventListener("click", () => requestGps(false));
    $("#btnMap").addEventListener("click", openMap);
    $("#btnLocClear").addEventListener("click", () => setLocation(null));
    $("#prevPlaces").addEventListener("change", onPlacePicked);
    $("#btnMapClose").addEventListener("click", () => closeMap(false));
    $("#btnMapOk").addEventListener("click", () => closeMap(true));
    $("#btnMapLocate").addEventListener("click", mapLocate);
    $("#catchDate").addEventListener("input", formatDateInput);
    $("#catchTime").addEventListener("input", formatTimeInput);
    $("#catchDate").addEventListener("blur", () => syncCatchTime(false));
    $("#catchTime").addEventListener("blur", () => syncCatchTime(false));
    $$(".chip[data-shift]").forEach((b) => b.addEventListener("click", () => shiftCatchTime(b.dataset.shift)));
    $("#btnCancelEdit").addEventListener("click", cancelEdit);
    $("#btnTripCtxCancel").addEventListener("click", () => {
      const id = state.tripCtx && state.tripCtx.tripId;
      resetForm();
      if (id && trips) { showTab("tabTrips"); trips.open(id, "catches"); }
    });
    $("#btnForgot").addEventListener("click", forgotPassword);
    $("#newPassForm").addEventListener("submit", onNewPassword);
    $("#btnHome").addEventListener("click", goHome);
    $(".brand").addEventListener("click", () => { if (state.me && state.me.approved && !$("#viewMain").classList.contains("hidden")) goHome(); });
    window.addEventListener("popstate", (e) => {
      if (!state.me || $("#viewMain").classList.contains("hidden")) return;
      $("#photoModal").classList.add("hidden"); $("#shareSheet").classList.add("hidden"); $("#mapModal").classList.add("hidden");
      showTab((e.state && e.state.tab) || "tabHome", { pop: true });
    });
    ["#fYear", "#fUser", "#fWater", "#fSpecies"].forEach((s) => $(s).addEventListener("change", renderLog));
    ["#fFrom", "#fTo"].forEach((s) => { $(s).addEventListener("input", onLogDateInput); $(s).addEventListener("blur", applyLogDate); });
    $("#fDateClear").addEventListener("click", () => setLogDate(null));
    try { const so = localStorage.getItem("logSort"); if (so && $(`#fSort option[value="${so}"]`)) $("#fSort").value = so; } catch (_) { /* nincs tároló */ }
    $("#fSort").addEventListener("change", () => { try { localStorage.setItem("logSort", $("#fSort").value); } catch (_) { /* nincs tároló */ } renderLog(); });
    $("#fDateChips").addEventListener("click", (e) => { const b = e.target.closest("[data-dr]"); if (b) setLogDate(quickRange(b.dataset.dr)); });
    ["#sYear", "#sMode", "#sSpecies"].forEach((s) => $(s).addEventListener("change", renderStats));
    $("#btnExport").addEventListener("click", exportCsv);
    $("#btnSync").addEventListener("click", () => syncOutbox());
    $("#btnRecheck").addEventListener("click", () => enterApp());
    $("#btnMembersBack").addEventListener("click", () => { show("viewMain"); });
    $("#btnMenu").addEventListener("click", (e) => { e.stopPropagation(); $("#menuPanel").classList.toggle("hidden"); });
    document.addEventListener("click", (e) => {
      if (!e.target.closest("#menuPanel") && !e.target.closest("#btnMenu") && !e.target.closest('[data-go="menu"]')) $("#menuPanel").classList.add("hidden");
      const act = e.target.closest("[data-action]");
      if (act) {
        const a = act.dataset.action;
        if (a === "logout") logout();
        if (a === "rename") rename();
        if (a === "members") showMembers();
        if (a === "quotes" && quotes) quotes.open();
        if (a === "admin" && admin) { admin.open(); if (cel && $("#celPreview")) $("#celPreview").innerHTML = cel.previewHtml(); }
        if (a === "celebrations" && cel) cel.openEdit(state.uid);
        if (a === "push") { $("#menuPanel").classList.add("hidden"); currentPushSub().then((s) => (s ? disablePush() : enablePush())); }
        if (a === "pushtest") { $("#menuPanel").classList.add("hidden"); testPush(); }
      }
      const hg = e.target.closest("[data-go]");
      if (hg) { e.stopPropagation(); onHomeGo(hg.dataset.go); return; }
      if (e.target.closest("[data-home-sync]")) syncOutbox();
      const hl = e.target.closest("[data-home-last]");
      if (hl) { state.highlight = { id: hl.dataset.homeLast, until: Date.now() + 5000, scrolled: false }; onHomeGo("tabLog"); }
      const del = e.target.closest(".btn-del");
      if (del) deleteEntry(del.dataset.id);
      const ed = e.target.closest(".btn-edit");
      if (ed) startEdit(ed.dataset.id);
      const rowBtn = e.target.closest(".crow[data-row]");
      if (rowBtn) toggleRow(rowBtn.dataset.row);
      const lv = e.target.closest("#logViewSeg [data-view]");
      if (lv) setLogView(lv.dataset.view);
      const sh = e.target.closest(".btn-share");
      if (sh) { const c = everyEntry().find((x) => x.client_id === sh.dataset.id); if (c) openShare(c, false); }
      const mem = e.target.closest("[data-member]");
      if (mem) setApproval(mem.dataset.member, mem.dataset.ok === "1");
    });
    $("#photoModal").addEventListener("click", (e) => { if (e.target.id === "photoModal") $("#photoModal").classList.add("hidden"); });

    // Értesítésre koppintva, ha az app már nyitva van: csak a címsor # része változik
    window.addEventListener("hashchange", () => {
      if (/^#meghivo-/i.test(location.hash) && family) {
        state.inviteToken = family.readToken();
        state.sb.auth.getSession().then(({ data }) => family.handleInvite(data.session)).catch(() => {});
        return;
      }
      if (state.me && state.me.approved && !$("#viewMain").classList.contains("hidden")) { refreshData(); openCatchFromHash(); }
    });
    window.addEventListener("online", () => { updateNet(); syncOutbox(); refreshData(); });
    window.addEventListener("offline", updateNet);
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "visible" && state.uid) { syncOutbox(); refreshData(); }
    });
    setInterval(() => { if (state.outbox.length) syncOutbox(); }, 60000);
    setInterval(tickCountdowns, 1000);
    // Karakterszámláló minden korlátos szövegmezőhöz (beszámoló, leírás, megjegyzés, memó)
    document.addEventListener("focusin", (e) => { if (isCounted(e.target)) updateCounter(e.target, true); });
    document.addEventListener("input", (e) => { if (isCounted(e.target)) updateCounter(e.target, true); });
    document.addEventListener("focusout", (e) => { if (isCounted(e.target)) updateCounter(e.target, false); });
  }

  const isCounted = (el) => el && el.tagName === "TEXTAREA" && el.maxLength > 0;
  const fmtInt = (n) => n.toLocaleString("hu-HU");
  function updateCounter(ta, active) {
    let c = ta.nextElementSibling;
    if (!c || !c.classList.contains("char-count")) {
      c = document.createElement("div");
      c.className = "char-count";
      c.setAttribute("aria-live", "polite");
      ta.insertAdjacentElement("afterend", c);
    }
    const max = ta.maxLength, used = ta.value.length, left = Math.max(0, max - used);
    const near = left <= Math.max(20, Math.round(max * 0.1));
    // Fókusz nélkül csak akkor marad látható, ha közel a korlát. A helye megmarad,
    // hogy az alatta lévő gomb ne ugorjon el koppintás közben.
    c.classList.toggle("idle", !active && !near);
    c.classList.toggle("near", near && left > 0);
    c.classList.toggle("full", left === 0);
    const post = ta.id === "postNew" || ta.classList.contains("post-edit");
    c.textContent = left === 0
      ? `Elérted a korlátot (${fmtInt(max)} karakter).${post ? " A folytatást írd új beszámolóba." : ""}`
      : `Még ${fmtInt(left)} karakter (${fmtInt(used)} / ${fmtInt(max)})`;
  }

  // Ha a böngésző még a régi index.html-t adja az új app.js mellé (gyorsítótár),
  // egyszer frissen újratöltjük az oldalt, ahelyett hogy hibára futnánk.
  async function reloadFresh() {
    let n = 0;
    try { n = Number(sessionStorage.getItem("freshReload") || 0); } catch (_) {}
    if (n >= 2) {
      toast("A frissítés még töltődik. Zárd be az appot, és pár perc múlva nyisd meg újra.", 10000);
      return;
    }
    try { sessionStorage.setItem("freshReload", String(n + 1)); } catch (_) {}
    try { await fetch("./index.html", { cache: "reload" }); } catch (_) {}
    try { if (window.caches) { const ks = await caches.keys(); await Promise.all(ks.map((k) => caches.delete(k))); } } catch (_) {}
    location.replace(location.pathname + "?v=" + Date.now() + location.hash);
  }
  if (!document.getElementById("logViewSeg") || !document.getElementById("photoGrid") || !document.getElementById("tabTrips") || !document.getElementById("recOut") || !document.getElementById("tabHome") || !document.getElementById("viewRedeem")) {
    reloadFresh();
    return;
  }
  try { sessionStorage.removeItem("freshReload"); } catch (_) {}

  start().catch((e) => {
    console.error(e);
    toast("Indítási hiba: " + errText(e), 6000);
  });
})();
